#include <iostream>

using namespace std;


/*
	Scrieti in limbaj de asamblare urmatoarea functie:

	void sumaMatrice(int **m1, int **m2, int **rezultat, int nrLinii, int nrColoane)
	{
		_asm
		{
			...
		}
	}

	Parametrii au urmatoarele semnificatii:
	m1 - adresa primei matrice (declarata dinamic)
	m2 - adresa celei de-a doua matrice (declarata dinamic)
	rezultat - adresa matricei rezultat (declarata dinamic)
	nrLinii - numarul de linii ale matricelor
	nrColoane - numarul de coloane ale matricelor


	Functia va calcula matricea rezultat dupa urmatoarea formula:
	daca linia este para, rezultat[i][j] = m1[i][j] + m2[i][j]
	daca linia este impara, rezultat[i][j] = m1[i][j] - m2[i][j]

*/


void sumaMatrice(int** m1, int** m2, int** rezultat, int nrLinii, int nrColoane)
{
	_asm
	{
		mov ecx, 0                     //ecx = 0 (il folosim ca si index pentru linie)
		_bucla_linii:
		cmp ecx, [ebp + 20]            //comparam indexul liniei cu numarul de linii
			je _am_parcurs_matricea        //daca indexul e egal cu numarul de linii, am terminat de parcurs programul
			mov edx, 0                     //edx = 0 (il folosim ca si index pentru coloane)
			_bucla_coloane :
			cmp edx, [ebp + 24]            //comparam indexul pentru coloane cu numarul de coloane
			je _reia_bucla_linii           //daca indexul e egal cu numarul de coloane, am parcurs linia, sari la _reia_bucla_linii
			mov esi, [ebp + 8]			   //esi = adresa primei matrice (adresa vectorului de adrese catre linii) 
			mov edi, [ebp + 12]            //edi = adresa celei de-a doua matrice
			mov eax, [esi + ecx * 4]       //eax = m1[ecx] (adresa liniei cu indexul ecx din matricea m1)
			mov eax, [eax + edx * 4]       //eax = m1[ecx][edx]
			mov ebx, [edi + ecx * 4]       //ebx = m2[ecx] (adresa liniei cu indexul ecx din matricea m2)
			mov ebx, [ebx + edx * 4]       //ebx = m2[ecx][edx]
			mov esi, ecx                   //esi = ecx (indexul liniei)
			and esi, 1                     //verific daca linia e para (daca un numar e impar, ultimul bit din reprezentarea sa binara e 1)
			cmp esi, 0                     //comparam esi cu 0 (daca e 0, indexul liniei e par, altfel e impar)
			je _linie_para                 //daca indexul e par, sar la _linie_para
			sub eax, ebx                   //indexul nu e par, calculez diferenta dintre m1[ecx][edx] si m2[ecx][edx]
			mov esi, [ebp + 16]            //esi = adresa matricei rezultat
			mov esi, [esi + ecx * 4]       //esi = rezultat[ecx] (adresa liniei cu indexul ecx din matricea rezultat)
			mov[esi + edx * 4], eax       //rezultat[ecx][edx] = eax
			inc edx                        //incrementam contorul pentru coloane
			jmp _bucla_coloane             //reiau a doua bucla

			_linie_para :
		add eax, ebx                   //indexul e par, calculez suma dintre m1[ecx][edx] si m2[ecx][edx]
			mov esi, [ebp + 16]            //esi = adresa matricei rezultat
			mov esi, [esi + ecx * 4]	   //esi = rezultat[ecx](adresa liniei cu indexul ecx din matricea rezultat)
			mov[esi + edx * 4], eax       //rezultat[ecx][edx] = eax
			inc edx                        //incrementam indexul pentru coloane
			jmp _bucla_coloane             //reiau a doua bucla

			_reia_bucla_linii :
		inc ecx                        //incrementam indexul pentru linii
			jmp _bucla_linii               //reia prima bucla

			_am_parcurs_matricea :
	}
}


int main()
{
	int** m1, ** m2, ** rezultat;
	int nrLinii = 3, nrColoane = 4;
	int i, j;

	m1 = new int* [nrLinii];
	m2 = new int* [nrLinii];
	rezultat = new int* [nrLinii];

	for (i = 0; i < nrLinii; ++i)
	{
		m1[i] = new int[nrColoane];
		m2[i] = new int[nrColoane];
		rezultat[i] = new int[nrColoane];
	}

	for (i = 0; i < nrLinii; ++i)
		for (j = 0; j < nrColoane; ++j)
		{
			m1[i][j] = 1;
			m2[i][j] = 1;
		}

	sumaMatrice(m1, m2, rezultat, nrLinii, nrColoane);

	for (i = 0; i < nrLinii; ++i)
	{
		for (j = 0; j < nrColoane; ++j)
		{
			cout << rezultat[i][j] << " ";
		}
		cout << "\n";
	}

	return 0;
}