#include <cstdio>

//Sa se scrie codul in limbaj de asamblare care verifica daca un numar natural > 1 este prim
/*
	Rezolvarea utilizeaza urmatorul algoritm:

	estePrim = 1;

	for(d = 2; d <= n/2; d++)
	{
		if (n % i == 0)
		{
			estePrim = 0;
			break;
		}
	}
*/

int estePrim(unsigned int a)
{
	int prim;

	_asm
	{
		mov eax, a             //eax = a
		mov edi, a             //edi = a facem o copie de care vom avea nevoie mai tarziu
		mov ebx, 2             //ebx = 2
		mov edx, 0             //edx = 0 !!!pregatim edx pentru operatia de impartire
		div ebx                //eax = ebx / 2 (setam limita pentru for - a/2)
		mov ebx, eax           //ebx = eax

		mov ecx, 2             //ecx - initializam contorul (echivalent cu variabila d din alg. descris mai sus)

		_bucla:
		cmp ecx, ebx           //comparam ecx (d) cu ebx (a / 2)
			ja _sfarsit_bucla      //daca ecx > ebx (d > a / 2), iesi din bucla
			mov eax, edi           //eax = edi = a
			mov edx, 0             //edx = 0 !!!pregatim edx pentru operatia de impartire
			div ecx                //eax = eax / ecx; edx = eax % ecx
			cmp edx, 0             //comparam restul impartirii (edx) cu 0
			je _nu_este_prim       //daca restul (edx) este 0, inseamna ca am gasit un divizor propriu; sari la _nu_este_prim
			inc ecx                //altfel, incrementeaza contorul ecx (d)
			jmp _bucla             //reia bucla

			_sfarsit_bucla :
		mov prim, 1            //am terminat bucla fara sa gasim un divizor propriu (fara sa sarim la _nu_este_prim); numarul este prim
			jmp _sfarsit           //sari la _sfarsit pentru a termina executia

			_nu_este_prim :
		mov prim, 0            //s-a gasit un divizor propriu; numarul NU este prim

			_sfarsit :
	}

	return prim;
}

int main()
{
	unsigned int numar;
	int prim;

	numar = 14;  //se poate modifica valoarea pentru a testa programul
	prim = estePrim(numar);

	if (prim)
	{
		printf("Numarul %d este prim!\n", numar);
	}
	else
	{
		printf("Numarul %d NU este prim!\n", numar);
	}


	return 0;
}