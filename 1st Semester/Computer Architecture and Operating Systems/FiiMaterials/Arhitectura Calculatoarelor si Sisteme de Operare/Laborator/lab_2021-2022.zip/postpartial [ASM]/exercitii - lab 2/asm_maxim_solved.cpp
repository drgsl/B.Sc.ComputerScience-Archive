#include <cstdio>

//Completati exemplul urmator astfel incat functia max sa returneze maximul dintre a si b

int max(int a, int b)
{
	int maxim;

	_asm
	{
		mov eax, a             //eax = a
		mov ebx, b             //ebx = b
		cmp eax, ebx           //compar eax cu ebx
		jge _eax_mai_mare      //daca eax este mai mare, sari la _eax_mai_mare
		mov maxim, ebx         //cazul in care ebx este mai mare; maxim = ebx si se sare la eticheta _sfarsit
		jmp _sfarsit
		_eax_mai_mare :
		mov maxim, eax         //cazul in care eax este mai mare; maxim = eax
		_sfarsit :
	}

	return maxim;
}

int main()
{
	int a, b;

	printf("a = ");
	scanf("%d", &a);
	printf("b = ");
	scanf("%d", &b);
	printf("MAX(a,b) = %d", max(a, b));

	return 0;
}