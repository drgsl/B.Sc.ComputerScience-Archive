#include <cstdio>

//Sa se scrie codul in limbaj de asamblare care calculeaza cel mai mare divizor comun pentru doua numere
/*
	Rezolvarea utilizeaza urmatorul algoritm:
	while (b != 0)
	{
		r = a % b;
		a = b;
		b = r;
	}

	la finalul executiei acestei bucle, a va retine valoarea celui mai mare divizor comun
*/

int main()
{
	unsigned int a, b, cmmdc;

	//puteti modifica valorile pentru a calcula cmmdc intre alte numere
	//pentru a = 123 si 87, CMMDC = 3
	a = 123;
	b = 87;

	_asm
	{
		mov eax, a                 //eax = a
		mov ebx, b                 //ebx = b

		_bucla :
		cmp ebx, 0                 //comparam ebx cu 0
			je _final                  //daca ebx == 0, sari la eticheta _final, bucla s-a terminat 
			mov edx, 0                 //edx = 0 !!!necesar pentru a face impartire
			div ebx                    //eax = eax / ebx; edx = eax % ebx; facem impartirea pentru a determina restul
			mov eax, ebx               //eax = ebx (echivalent liniei a = b)
			mov ebx, edx               //ebx = edx (echivalent liniei b = r)
			jmp _bucla                 //reia bucla

			_final :
		mov cmmdc, eax             //cmmdc = eax (in eax se va afla cel mai mare divizor comun)
	}


	printf("CMMDC(%d, %d) = %d", a, b, cmmdc);

	return 0;
}