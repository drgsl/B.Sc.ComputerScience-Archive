#include <cstdio>


int main()
{
	//compilare si rulare ctrl + f5 
	//compliare si rulare in mod debug f5

	int sum_int;
	unsigned char sum_char_unsigned;
	char sum_char_signed;

	_asm
	{
		mov eax, 10          //eax = 10
		add eax, 100         //eax = eax + 100
		mov sum_int, eax     //sum_int = eax
	}

	printf("Am obtinut suma %d\n", sum_int); //ar trebui sa afiseze "Am obtinut suma 110"

	_asm
	{
		mov eax, 67         //eax = 67
		mov ebx, 287        //ebx = 287
		add ebx, eax        //ebx = ebx + eax
		mov sum_int, ebx    //sum_int = ebx
	}

	printf("Am obtinut suma %d\n", sum_int); //ar trebui sa afiseze "Am obtinut suma 354"

	//caz in care se seteaza CF (bitul corespunzator devine 1)
	//al si bl sunt registri pe 8 biti
	//consideram ca lucram cu numere FARA SEMN
	//valoare maxima FARA SEMN reprezentabila pe 8 biti este 255
	_asm
	{
		mov al, 200                      //al = 200
		mov bl, 100                      //bl = 100
		add al, bl                       //al = al + bl
		mov sum_char_unsigned, al        //sum_char_unsigned = al
	}

	//Dupa cum se poate observa, rezultatul sumei ar trebui sa fie 300, aceasta valoare nu se poate reprezenta pe 8 biti
	//In consecinta, rezultatul operatiei va fi gresit si se va seta CF (carry flag)
	printf("Am obtinut suma %d\n", sum_char_unsigned); //ar trebui a afiseze "Am obtinut suma 44"


	//caz in care se seteaz OF (bitul corespunzator devine 1)
	//al si bl sunt registri pe 8 biti
	//consideram ca lucram cu numere CU SEMN
	//valorile reprezentabile CU SEMN pe 8 biti sunt cele din intervalul [-128; 127]
	_asm
	{
		mov al, 18                     //al = 18
		mov bl, 127                    //bl = 127
		add al, bl                     //al = al + bl
		mov sum_char_signed, al        //sum_char_signed = al
	}
	//Dupa cum se poate observa, daca lucram cu numere cu semn, rezultatul sumei ar trebui sa fie 145, insa aceasta
	//valoare iese din intervalul reprezentabil pe 8 biti cu semn
	//In consecinta, rezultatul operatiei va fi gresit si se va seta OF (overflow flag)
	printf("Am obtinut suma %d\n", sum_char_signed); //ar trebui a afiseze "Am obtinut suma -111"

	return 0;
}