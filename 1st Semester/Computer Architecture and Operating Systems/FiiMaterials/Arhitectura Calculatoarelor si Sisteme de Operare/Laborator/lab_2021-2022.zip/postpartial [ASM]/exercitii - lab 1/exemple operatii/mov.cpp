#include <cstdio>


int main()
{
	//compilare si rulare ctrl + f5 
	//compliare si rulare in mod debug f5

	int value;
	_asm
	{
		mov eax, 5          //eax = 5  
		mov value, eax      //value = 5
	}

	printf("Am pus %d in registrul eax \n", value); //ar trebui sa se afiseze: "Am pus 5 in registrul eax"

	_asm 
	{

		mov eax, -100      //eax = -100
		mov ebx, eax       //ebx = eax
		mov value, ebx     //value = ebx
	}

	printf("Am pus %d in registrul eax, iar apoi am mutat valoare din eax in ebx \n", value);
	//ar trebui sa se afiseze: "Am pus -100 in registrul eax, iar apoi am mutat -100 din eax in ebx"

	return 0;
}