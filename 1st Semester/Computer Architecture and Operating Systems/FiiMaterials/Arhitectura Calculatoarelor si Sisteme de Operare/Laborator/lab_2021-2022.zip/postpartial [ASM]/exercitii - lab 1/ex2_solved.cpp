#include <cstdio>

//Sa se scrie codul in limbaj de asamblare care oglindeste bitii unui numar

int main()
{
	unsigned char number;
	number = 140;

	_asm {
		mov al, number         //al = number
		mov cl, 0              //cl = 0; rezultatul final se va afla in acest registru

		/*
			mutam bit-ul cu indicele 0 in registrul al pe pozitia 7 in registrul cl
		*/

		mov bl, al             //bl = al
		and bl, 00000001b      //bl = bl AND 1 (000000001); echivalent cu instructiunea and bl, 1
		shl bl, 7              //bl = bl << 7
		or cl, bl              //cl = cl OR bl

		/*
			mutam bit-ul cu indicele 1 in registrul al pe pozitia 6 in registrul cl
		*/

		mov bl, al
		and bl, 00000010b     //echivalent cu instructiunea and bl, 2
		shl bl, 5
		or cl, bl

		/*
			mutam bit-ul cu indicele 2 in registrul al pe pozitia 5 in registrul cl
		*/

		mov bl, al
		and bl, 00000100b     //echivalent cu instructiunea and bl, 4
		shl bl, 3
		or cl, bl

		/*
			mutam bit-ul cu indicele 3 in registrul al pe pozitia 4 in registrul cl
		*/

		mov bl, al
		and bl, 00001000b     //echivalent cu instructiunea and bl, 8
		shl bl, 1
		or cl, bl

		/*
			mutam bit-ul cu indicele 4 in registrul al pe pozitia 3 in registrul cl
		*/

		mov bl, al
		and bl, 00010000b    //echivalent cu instructiunea and bl, 16
		shr bl, 1
		or cl, bl

		/*
			mutam bit-ul cu indicele 5 in registrul al pe pozitia 2 in registrul cl
		*/

		mov bl, al
		and bl, 00100000b    //echivalent cu instructiunea and bl, 32
		shr bl, 3
		or cl, bl

		/*
			mutam bit-ul cu indicele 6 in registrul al pe pozitia 1 in registrul cl
		*/

		mov bl, al
		and bl, 01000000b   //echivalent cu instructiunea and bl, 64
		shr bl, 5
		or cl, bl

		/*
			mutam bitul cu indicele 7 in registrul al pe pozitia 0 in registrul cl
		*/

		mov bl, al
		and bl, 10000000b
		shr bl, 7
		or cl, bl

		mov number, cl    //number = cl
	}

	if (number != 49)
		printf("Failed! Your result is %d\n", number);
	else
		printf("OK!");

	return 0;
}