#include <cstdio>

using namespace std;

int main()
{
	//compilare si rulare ctrl + f5 
	//compliare si rulare in mod debug f5

	unsigned char unsigned_value;
	char signed_value;

	/*===EXEMPLE INSTRUCTIUNE SHR===*/

	//consideram numere FARA SEMN
	_asm
	{
		mov al, 20                //al = 20 = 00010100
		shr al, 1				  //deplasam bitii lui al cu o pozitie la dreapta; al devine 00001010 = 10
		mov unsigned_value, al    //unsigned_value = al  
	}

	printf("Rezultatul este %d\n", unsigned_value); //ar trebui sa afiseze "Rezultatul este 10"

	//consideram numere CU SEMN
	_asm
	{
		mov bl, -28           //bl = -28 = 11100100
		mov cl, 2			  //cl = 2
		shr bl, cl            //deplasam bitii lui bl cu doua pozitii la dreapta; bl devine 00111001 = 57
		mov signed_value, bl  //signed_value = bl
	}
	//OBSERVATIE: shr nu poate fi utilizata in scop aritmetic (pentru a realiza impartirea la o putere a lui 2)
	//in cadrul numerelor CU SEMN deoarece pentru numere negative rezultatul va fi unul eronat 
	//(bitul de semn va deveni 0)


	printf("Rezultatul este %d\n", signed_value); //ar trebui sa afiseze "Rezultatul este 57"

	/*===SFARSIT EXEMPLE INSTRUCTIUNE SHL===*/


	/*===EXEMPLE INSTRUCTIUNE SAR===*/

	//consideram numere FARA SEMN
	_asm
	{
		mov al, 20                //al = 20 = 00010100
		sar al, 1				  //deplasam bitii lui al cu o pozitie la dreapta; al devine 00101010 = 10
		mov unsigned_value, al    //unsigned_value = al   
	}

	printf("Rezultatul este %d\n", unsigned_value); //ar trebui sa afiseze "Rezultatul este 10"

	//consideram numere CU SEMN
	_asm
	{
		mov bl, -28           //bl = -28 = 11100100
		mov cl, 2             //cl = 2
		sar bl, cl            //deplasam bitii lui bl cu doua pozitii la dreapta; bl devine 11111001 = -7
		mov signed_value, bl  //signed_value = bl
	}

	printf("Rezultatul este %d\n", signed_value); //ar trebui sa afiseze "Rezultatul este -7"
	//OBSERVATIE: utilizat in scop aritmetic, sar produce valoarea dorita pentru numere negative

	/*===SFARSIT EXEMPLE INSTRUCTIUNE SAL===*/

	/*ALTE OBSERVATII:
		* pentru numere FARA SEMN si POZITIVE CU SEMN, SAR si SHR se comporta identic
			* pentru acestea deplasarea cu n pozitii la dreapta prin intermediul instructiunilor este echivalenta
			  cu impartirea la 2^n
		* pentru numere NEGATIVE CU SEMN
			* SHR realizeaza o deplasare logica a bitilor (realizeaza pur si simplu o shiftare la dreapta)
			* SAR realizeaza o deplasare in scop aritmetic - o deplasare cu n pozitii la dreapta utilizand
			  aceasta instructiune este echivalenta cu impartirea numarului la 2^n
	*/
	return 0;
}