#include <cstdio>

using namespace std;

int main()
{
	//compilare si rulare ctrl + f5 
	//compliare si rulare in mod debug f5

	unsigned int unsigned_value_edx, unsigned_value_eax;
	int signed_value_edx, signed_value_eax;

	//lucram cu numere FARA SEMN
	_asm
	{
		mov eax, 12     //eax = 12
		mov ebx, 4      //ebx = 4
		mul ebx         //edx:eax = eax * ebx

		mov unsigned_value_eax, eax

		/*rezultatul operatiei este 48, acesta va fi reprezentat pe 64 de biti, cei mai semnificativi 32
		  se vor afla in edx, iar cei mai putini semnificativi in eax

		  48 = 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00110000
		  edx = 00000000 00000000 00000000 00000000
		  eax = 00000000 00000000 00000000 00110000

		  dupa cum se poate observa rezultatul incape pe 32 de biti, deci putem ignora valoarea din edx si sa lucram
		  mai departe doar cu eax

		  in acest caz, rezultatul inmultirii va fi rezultatul retinut in eax*/
	}

	printf("Rezultatul inmultirii este %u\n", unsigned_value_eax); //ar trebui sa afiseze "Rezultatul inmultirii este 48"


	//lucram cu numere FARA SEMN
	_asm
	{
		mov eax, 2000000000     //eax = 2000000000
		mov ebx, 4              //ebx = 4
		mul ebx                 //edx:eax = eax * ebx

		mov unsigned_value_eax, eax

		/*
		  rezultatul operatiei este 8000000000, acesta va fi reprezentat pe 64 de biti, cei mai semnificativi 32
		  se vor afla in edx, iar cei mai putini semnificativi in eax

		  8000000000 = 00000000 00000000 00000000 00000001 11011100 11010110 01010000 00000000
		  edx = 00000000 00000000 00000000 00000001
		  eax = 11011100 11010110 01010000 00000000

		  dupa cum se poate observa rezultatul NU incape pe 32 de biti, deci NU putem ignora valoarea din edx
		  este gresit sa lucram doar cu valoarea lui eax in acest caz
		*/
	}
	//dupa cum se poate observa, daca vom considera ca si rezultat doar valoarea din eax, vom lucra gresit

	printf("Valoarea din eax %u\n", unsigned_value_eax); //ar trebui sa afiseze "Valoarea din eax este 3705032704"


	//lucram cu numere CU SEMN
	_asm
	{
		mov eax, -12     //eax = -12
		mov ebx, 4       //ebx = 4
		imul ebx         //edx:eax = eax * ebx

		mov signed_value_edx, edx
		mov signed_value_eax, eax

		/*rezultatul operatiei este -48, acesta va fi reprezentat pe 64 de biti, cei mai semnificativi 32
		  se vor afla in edx, iar cei mai putini semnificativi in eax

		  -48 = 11111111 11111111 11111111 11111111 11111111 11111111 11111111 11010000
		  edx = 11111111 11111111 11111111 11111111
		  eax = 11111111 11111111 11111111 11010000

		  dupa cum se poate observa rezultatul incape pe 32 de biti, deci putem ignora valoarea din edx si sa lucram
		  mai departe doar cu eax

		  in acest caz, rezultatul inmultirii va fi rezultatul retinut in eax*/
	}

	printf("Rezultatul inmultirii este %d\n", signed_value_eax); //ar trebui sa afiseze "Rezultatul inmultirii este -48"


	//lucram cu numere CU SEMN
	_asm
	{
		mov eax, -2000000000     //eax = 12
		mov ebx, 4              //ebx = 4
		imul ebx                 //edx:eax = eax * ebx

		mov unsigned_value_eax, eax

		/*
		  rezultatul operatiei este -8000000000, acesta va fi reprezentat pe 64 de biti, cei mai semnificativi 32
		  se vor afla in edx, iar cei mai putini semnificativi in eax

		  -8000000000 = 11111111 11111111 11111111 11111110 00100011 00101001 10110000 00000000
		  edx = 11111111 11111111 11111111 11111110
		  eax = 00100011 00101001 10110000 00000000

		  dupa cum se poate observa rezultatul NU incape pe 32 de biti, deci NU putem ignora valoarea din edx
		  este gresit sa lucram doar cu valoarea lui eax in acest caz
		*/
	}
	//dupa cum se poate observa, daca vom considera ca si rezultat doar valoarea din eax, vom lucra gresit

	printf("Valoarea din eax %u\n", signed_value_eax); //ar trebui sa afiseze "Valoarea din eax este 4294967248"



	return 0;
}