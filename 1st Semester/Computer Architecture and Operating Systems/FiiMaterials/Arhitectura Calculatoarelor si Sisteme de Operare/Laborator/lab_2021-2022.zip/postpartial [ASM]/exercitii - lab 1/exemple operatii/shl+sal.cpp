#include <cstdio>

using namespace std;

int main()
{
	//compilare si rulare ctrl + f5 
	//compliare si rulare in mod debug f5

	unsigned char unsigned_value;
	char signed_value;

	/*===EXEMPLE INSTRUCTIUNE SHL===*/

	//consideram numere FARA SEMN
	_asm
	{
		mov al, 21                //al = 21 = 00010101
		shl al, 1				  //deplasam bitii lui al cu o pozitie la stanga; al devine 00101010 = 42
		mov unsigned_value, al    //unsigned_value = al   
	}

	printf("Rezultatul este %d\n", unsigned_value); //ar trebui sa afiseze "Rezultatul este 42"

	//consideram numere CU SEMN
	_asm
	{
		mov bl, -14           //bl = -14 = 11110010
		mov cl, 2			  //cl = 2
		shl bl, cl            //deplasam bitii lui bl cu doua pozitii la stanga; bl devine 11001000 = -56
		mov signed_value, bl  //signed_value = bl
	}

	printf("Rezultatul este %d\n", signed_value); //ar trebui sa afiseze "Rezultatul este -56"

	/*===SFARSIT EXEMPLE INSTRUCTIUNE SHL===*/


	/*===EXEMPLE INSTRUCTIUNE SAL===*/

	//consideram numere FARA SEMN
	_asm
	{
		mov al, 21                //al = 21 = 00010101
		sal al, 1				  //deplasam bitii lui al cu o pozitie la stanga; al devine 00101010 = 42
		mov unsigned_value, al    //unsigned_value = al   
	}

	printf("Rezultatul este %d\n", unsigned_value); //ar trebui sa afiseze "Rezultatul este 42"

	//consideram numere CU SEMN
	_asm
	{
		mov bl, -14           //bl = -14 = 11110010
		mov cl, 2             //cl = 2
		sal bl, cl            //deplasam bitii lui bl cu doua pozitii la stanga; bl devine 11001000 = -56
		mov signed_value, bl  //signed_value = bl
	}

	printf("Rezultatul este %d\n", signed_value); //ar trebui sa afiseze "Rezultatul este -56"

	/*===SFARSIT EXEMPLE INSTRUCTIUNE SAL===*/

	/*OBSERVATII:
		SHL si SAL produc ACELASI REZULTAT
		operatia de DEPLASARE LA STANGA CU n POZITII este ECHIVALENTA cu INMULTIREA CU 2^n
	*/

	return 0;
}