#include <cstdio>

using namespace std;

int main()
{
	//compilare si rulare ctrl + f5 
	//compliare si rulare in mod debug f5

	unsigned int unsigned_cat, unsigned_rest;
	int signed_cat, signed_rest;

	//lucram cu numere FARA SEMN
	_asm
	{
		/*vrem sa impartim 12 la 7 utilizand varianta in care punem deimpartitul in edx:eax

		  deimpartitul va fi reprezentat pe 64 de biti, cei mai semnificativi 32 se vor afla in edx,
		  cei mai putin semnificativi in edx

		  12 = 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00001100
		  edx = 00000000 00000000 00000000 00000000 = 0
		  eax = 00000000 00000000 00000000 00001100 = 12

		  dupa cum se poate observa, daca deimpartitul incape pe 32 de biti (4 octeti), este suficient
		  sa punem valoarea acestuia in registrul eax si TREBUIE SA PUNEM 0 in edx
		*/

		mov eax, 12
		mov edx, 0
		mov ebx, 7
		div ebx
		mov unsigned_cat, eax
		mov unsigned_rest, edx
	}

	printf("Catul este %u, iar restul este %u\n", unsigned_cat, unsigned_rest);
	//ar trebui sa se afiseze "Catul este 1, iar restul este 5"


	//lucram cu numere CU SEMN
	_asm
	{
		/*vrem sa impartim -12 la 7 utilizand varianta in care punem deimpartitul in edx:eax

		  deimpartitul va fi reprezentat pe 64 de biti, cei mai semnificativi 32 se vor afla in edx,
		  cei mai putin semnificativi in edx

		  -12 = 11111111 11111111 11111111 11111111 11111111 11111111 11111111 11110100
		  edx = 11111111 11111111 11111111 11111111 = -1
		  eax = 11111111 11111111 11111111 11110100 = -12

		  dupa cum se poate observa, daca deimpartitul incape pe 32 de biti (4 octeti), este suficient
		  sa punem valoarea acestuia in registrul eax si TREBUIE SA PUNEM -1 in edx
		*/

		mov eax, -12
		mov edx, -1
		mov ebx, 7
		idiv ebx
		mov signed_cat, eax
		mov signed_rest, edx
	}

	printf("Catul este %d, iar restul este %d\n", signed_cat, signed_rest);
	//ar trebui sa se afiseze "Catul este -1, iar restul este -5"

	return 0;
}