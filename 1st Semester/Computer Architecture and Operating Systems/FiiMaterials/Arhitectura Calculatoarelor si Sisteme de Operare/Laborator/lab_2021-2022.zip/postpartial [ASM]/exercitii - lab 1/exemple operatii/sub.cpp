#include <cstdio>


int main()
{
	//compilare si rulare ctrl + f5 
	//compliare si rulare in mod debug f5

	int diff;
	unsigned char diff_char_unsigned;
	char diff_char_signed;

	_asm
	{
		mov eax, 100    //eax = 100
		sub eax, 250    //eax = eax - 250
		mov diff, eax   //diff = eax
	}

	printf("Am obtinut diferenta %d\n", diff); //ar trebui sa se afiseze "Am obtinut diferenta -150"

	_asm
	{
		mov ebx, 1000     //ebx = 1000
		mov eax, 260      //eax = 260
		sub ebx, eax      //ebx = ebx - eax
		mov diff, ebx     //diff = ebx
	}

	printf("Am obtinut diferenta %d\n", diff); //ar trebui sa se afiseze "Am obtinut diferenta 740"


	//caz in care se seteaza CF (bitul corespunzator devine 1)
	//al si bl sunt registri pe 8 biti
	//consideram ca lucram cu numere FARA SEMN
	//valoarile reprezentabile FARA SEMN pe 8 biti sunt in intervalul [0, 255]

	_asm
	{
		mov al, 10                        //al = 10
		mov bl, 20						  //bl = 20
		sub al, bl                        //al = al - bl
		mov diff_char_unsigned, al        //diff_char_unsigned = al
	}

	//Dupa cum se poate observa, rezultatul diferentei ar trebui sa fie -10, insa aceasta valoare iese din intervalul
	//care poate fi reprezentat pe 8 biti fara semn
	//In consecinta, rezultatul operatiei va fi gresit si se va seta CF (carry flag)
	printf("Am obtinut diferenta %d\n", diff_char_unsigned); //ar trebui sa se afiseze "Am obtinut diferenta 246"


	//caz in care se seteaza OF (bitul corespunzator devine 1)
	//al si bl sunt registri pe 8 biti
	//consideram ca lucram cu numere CU SEMN
	//valoarile CU SEMN reprezentabile pe 8 biti sunt in intervalul [-128; 127]

	_asm
	{
		mov al, -100
		mov bl, 90
		sub al, bl
		mov diff_char_signed, al
	}
	//Rezultatul diferentei ar trebui sa fie -190, insa aceasta valoarea iese din intervalul [-128, 127]
	//In consecinta, rezultatul operatiei va fi gresit si se va seta OF (overflow flag)

	printf("Am obtinut diferenta %d\n", diff_char_signed); //ar trebui sa se afiseze "Am obtinut diferenta 66"

	return 0;
}