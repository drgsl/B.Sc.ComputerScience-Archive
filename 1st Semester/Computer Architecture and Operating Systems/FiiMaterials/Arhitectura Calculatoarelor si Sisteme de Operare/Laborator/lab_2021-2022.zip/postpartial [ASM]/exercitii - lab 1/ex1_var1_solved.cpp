#include <iostream>

using namespace std;

//Sa se scrie codul in limbaj de asamblare care calculeaza suma : 1 + 2 + 3 + ... + n
//Obs: presupunem ca rezultatele intermediare incap pe 4 octeti

//1 + 2 + 3 + ... + n = n * (n + 1) / 2

int main()
{
	unsigned int n = 10;
	unsigned int rezultat;

	_asm
	{
		mov eax, n         //eax = n
		mov ebx, eax       //ebx = eax = n
		inc eax            //eax = eax + 1 = n + 1
		mul ebx            //(edx:eax) = eax * ebx = n * (n + 1)
		mov ecx, 2         //ecx = 2
		div ecx            //eax = (edx:eax) / ecx ; edx = (edx, eax) % ecx	
		mov rezultat, eax
	}

	cout << "Rezultatul este: " << rezultat;

	return 0;
}