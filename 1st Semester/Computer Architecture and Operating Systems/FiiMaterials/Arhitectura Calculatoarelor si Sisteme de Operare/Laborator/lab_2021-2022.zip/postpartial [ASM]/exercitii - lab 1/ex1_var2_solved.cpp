#include <stdio.h>
#define LEAST_SEMNIF 55607
#define SEMNIF 1

//Sa se scrie codul in limbaj de asamblare care calculeaza suma: 1+2+3+...+n, unde n = 92682 
//Atentie, aceasta suma nu se poate reprezenta folosind doar 32 de biti.

int main()
{
	int n;
	n = 92682;
	int least_semnif, semnif;

	_asm
	{
		mov eax, n                      //eax = n = 92682
		mov ebx, eax                    //ebx = eax = 92682     (valoarea lui n)
		inc ebx                         //ebx = ebx + 1 = 92683 (valoarea lui n + 1)
		mul ebx                         //edx:eax = eax * ebx = 92682 * 92683 (calculam n * (n + 1))

		//analizam cazul particular in care n = 92682
		/*rezultatul operatiei de inmultire arata astfel
			92682 * 92683 = 8590045806 = 00000000 00000000 00000000 00000010 00000000 00000001 10110010 01101110
			edx = 00000000 00000000 00000000 00000010
			eax = 00000000 00000001 10110010 01101110

			pentru a imparti rezultatul la 2, putem deplasa bitii rezultatului cu o pozitie la dreapta
			acest lucru este echivalent cu a deplasa bitii lui edx si eax cu o pozitie la dreapta
		*/

		/*se deplaseaza bitii lui eax cu o pozitie la dreapta
			in particular, eax devine 00000000 00000000 11011001 00110111
		*/

		shr eax, 1
		mov ebx, edx                //ebx = edx; in particular, ebx = 00000000 00000000 00000000 00000010

		/*
			se deplaseaza bitii lui edx cu o pozitie la dreapta
			in particular, edx devine 00000000 00000000 00000000 00000001
		*/

		shr edx, 1

		/*
			in cazul acestei abordari utilizate pentru impartirea rezultatului inmultirii la 2, apare o problema

			in cadrul shiftarii bitilor din rezultat, se poate observa ca cel mai putin semnificativ bit al lui edx
			ar trebui sa se duca pe pozitia celui mai semnificativ bit al lui eax

			utilizand doar operatiile curente, cel mai semnificativ bit al lui eax va fi mereu 0

			avem nevoie de o metoda prin care pe acea pozitie sa punem cel mai putin semnificativ bit al lui edx

			acest lucru se face altfel:
				pastram valoarea lui edx intr-un registrul auxiliar (in cazul nostru, am facut mai sus ebx = edx)

				shiftam la stanga cu 31 de pozitii valoarea din registrul ebx
					va rezulta un sir de biti in care pe cel mai semnificativ bit va ajunge cel mai putin semificativ
					bit care se afla anterior in sir, iar restul bitilor vor fi 0

				facem o operatie or intre registrul auxiliar si eax
					efectul va fi ca cel mai semnificativ bit al lui eax va prelua valoarea celui mai semnificativ
					bit din registrul auxiliar (care este de fapt cel mai putin semnificativ bit al lui edx) iar
					restul bitilor lui eax vor ramane neschimbati

			cum arata asta pe cazul nostru concret
				edx = 00000000 00000000 00000000 00000010   valoare inainte de shiftare
				eax = 00000000 00000001 10110010 01101110   valoare inainte de shiftare

				ebx = edx = 00000000 00000000 00000000 00000010

				se shifteaza registrii
				edx = 00000000 00000000 00000000 00000001   valoare dupa de shiftare
				eax = 00000000 00000000 11011001 00110111   valoare dupa de shiftare

				eax trebuie sa aiba pe cel mai semnificativ bit cel mai putin semnificativ bit al lui edx inainte
				de shiftare

				se shifteaza ebx cu 31 de pozitii la dreapta
				ebx = 00000000 00000000 00000000 00000000

				se observa ca ebx are ca cel mai semnificativ bit 0 (care este cel mai putin semnificativ bit
				al lui edx inainte de shiftare), iar restul bitilor sunt 0

				se face operatia OR intre eax si ebx
				eax = eax or ebx = 00000000 00000000 11011001 00110111 or 00000000 00000000 00000000 00000000
				eax = 00000000 00000000 11011001 00110111

				rezultatul final este 00000000 00000000 00000000 00000001 00000000 00000000 11011001 00110111
				edx = 00000000 00000000 00000000 00000001
				eax = 00000000 00000000 11011001 00110111
		*/

		shl ebx, 31
		or eax, ebx

		/*
			mutam edx si eax in cele doua variabile pentru a verifica ulterior daca rezultatul este corect
		*/

		mov semnif, edx
		mov least_semnif, eax
	}

	if (least_semnif == LEAST_SEMNIF && SEMNIF == semnif)
	{
		printf("Ok!\n");
	}
	else
	{
		printf("Rezultat gresit!\n");
	}
	return 0;
}