#include <iostream>

using namespace std;

//Sa se scrie o functie care insereaza un element intr-un vector sortat.
//vectorul este sortat

void sortare(int* vector, int nr_elemente, int nr_max, int valoare)
{
	_asm
	{
		mov edx, [ebp + 8]  //edx = adresa vectorului
		mov edi, [ebp + 12] //edi = nr_elemente
		cmp edi, [ebp + 16] //compar nr_elemente cu nr_max
		je _exit_program  //daca sunt egale, ies din functie

		mov ecx, 0  //ecx = 0 - counter
		_bucla_parcurgere:
		cmp ecx, edi          //comparam contor cu nr_elemente
			je _inserare_dupa     //daca sunt egale, inseamna ca nu am gasit vreo valoare mai mare in vector si trebuie sa punem la urma

			mov ebx, [ebp + 20]   //ebx = valoare
			cmp ebx, [edx + ecx * 4] //comparam valoare cu vector[ecx]
			jle _mutare_elemente            //daca ebx <= vector[ecx], sari la _inserare
			inc ecx                  //incrementam ecx
			jmp _bucla_parcurgere    //reluam parcurgerea

			_mutare_elemente :
		mov eax, [ebp + 12] //eax = nr_elemente
			dec eax             //eax = nr_elemente - 1
			_bucla_mutare :
		cmp eax, ecx        //comparam eax, cu ecx
			jl _inserare_element         //daca eax < ecx, am ajuns pe pozitia unde trebuie sa inseram elementul
			mov esi, [edx + eax * 4]     //esi = vector[eax]
			mov[edx + eax * 4 + 4], esi //vector[eax + 1] = esi
			dec eax                      //eax--
			jmp _bucla_mutare            //reia bucla mutare

			_inserare_element :
		mov[edx + ecx * 4], ebx     //vector[edx] = ebx = valoare
			jmp _exit_program

			_inserare_dupa :
		mov ebx, [ebp + 20]   //ebx = valoare
			mov[edx + edi * 4], ebx  //vector[nr_elemente] = valoare


			_exit_program :
	}
}

int main()
{
	int vector[10] = { 1, 2, 3, 4, 7, 8, 0, 0, 0, 0 };
	int nr_elemente = 6, nr_max = 10, valoare = 6;

	sortare(vector, nr_elemente, nr_max, valoare);

	for (int i = 0; i < nr_max; ++i)
	{
		cout << vector[i] << " ";
	}

	return 0;
}