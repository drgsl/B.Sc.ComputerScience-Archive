<!-- Copyright (c) 2013-2016 K Team. All Rights Reserved. -->

Explain the lack of tenv(...)?
