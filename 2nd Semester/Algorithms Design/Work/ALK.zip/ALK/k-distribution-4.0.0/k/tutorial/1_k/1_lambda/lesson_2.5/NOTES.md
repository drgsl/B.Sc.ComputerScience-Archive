<!-- Copyright (c) 2016 K Team. All Rights Reserved. -->

This folder has been added after the original tutorial was made
and after the videos were recorded.  Eventually we will renumber
the lessons and redo the videos.  A README.md file is also needed
here.
