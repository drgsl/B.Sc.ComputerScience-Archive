<!-- Copyright (c) 2016 K Team. All Rights Reserved. -->

Maybe we should define simply-typed lambda calculus in some earlier
lecture in tutorial 1, and then reuse its examples here.
