<!-- Copyright (c) 2014-2016 K Team. All Rights Reserved. -->

The README needs to be changed to reflect the fact that we now have a builtin
unification procedure.
