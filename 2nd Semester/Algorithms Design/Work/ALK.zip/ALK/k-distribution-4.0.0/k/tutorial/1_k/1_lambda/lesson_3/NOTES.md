<!-- Copyright (c) 2016 K Team. All Rights Reserved. -->

When we say "previous lesson" we refer to lesson 2.  This will need to change
when we incorporate lesson 2.5 properly.
