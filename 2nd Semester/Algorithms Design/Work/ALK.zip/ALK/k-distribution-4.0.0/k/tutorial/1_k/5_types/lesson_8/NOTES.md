<!-- Copyright (c) 2012-2016 K Team. All Rights Reserved. -->

We also have to redeclare lambda and mu as binders.  Program
tricky-2.lambda shows why.
