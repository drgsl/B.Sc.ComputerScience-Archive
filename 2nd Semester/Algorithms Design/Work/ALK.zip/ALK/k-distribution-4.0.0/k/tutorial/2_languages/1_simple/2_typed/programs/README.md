<!-- Copyright (c) 2014-2016 K Team. All Rights Reserved. -->

The programs in this folder are typed variants of the SIMPLE untyped programs.
These programs will be executed both with the dynamic and with the static
semantics of the typed SIMPLE language.  Each of the semantics contains its
own results folder showing the expected results of executing these programs.
