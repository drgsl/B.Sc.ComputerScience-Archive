<!-- Copyright (c) 2015-2016 K Team. All Rights Reserved. -->

We now support the following line to the syntax module:

    syntax priority lambda_._ > __  // exact syntax subject to change

This will allow for fewer parentheses in programs.
