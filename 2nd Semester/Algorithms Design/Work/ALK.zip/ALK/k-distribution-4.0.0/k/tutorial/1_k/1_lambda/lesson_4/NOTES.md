<!-- Copyright (c) 2016 K Team. All Rights Reserved. -->

The --pdf and --htmp options have changed, so the video is currently
obsolete.  See `kompile --help` for the new syntax.

README.md refers to Lesson 9.  This will need to be updated.
