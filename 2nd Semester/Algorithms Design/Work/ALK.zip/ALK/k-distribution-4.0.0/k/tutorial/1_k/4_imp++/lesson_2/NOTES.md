<!-- Copyright (c) 2016 K Team. All Rights Reserved. -->

update discussion on fresh; it has already been explained in lambda++
