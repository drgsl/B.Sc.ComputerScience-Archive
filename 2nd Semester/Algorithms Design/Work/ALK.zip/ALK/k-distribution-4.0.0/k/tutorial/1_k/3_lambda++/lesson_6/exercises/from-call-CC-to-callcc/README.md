<!-- Copyright (c) 2013-2016 K Team. All Rights Reserved. -->

Define `callcc` in terms of `callCC`, where `callCC` is explained in the
`callCC` exercise under LAMBDA++, Lesson 1.  Follow an environment-based style.
