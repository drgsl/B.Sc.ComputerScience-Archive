<!-- Copyright (c) 2013-2016 K Team. All Rights Reserved. -->

(see similar exercise in Lesson 1, with substitution instead of environments)

Define a variant of `callcc`, say `callCC`, which never returns to the
current context unless a value is specifically passed to its argument
continuation.  Follow an environment-based style.
