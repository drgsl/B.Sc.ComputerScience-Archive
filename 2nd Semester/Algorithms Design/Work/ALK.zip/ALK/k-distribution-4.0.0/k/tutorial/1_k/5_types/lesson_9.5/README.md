<!-- Copyright (c) 2014-2016 K Team. All Rights Reserved. -->

This definition requires the new java-based rewrite engine of K,
which is currently experimental.  So use the option `--backend java`
when you `kompile` it (and possibly also the same option with `krun`).
