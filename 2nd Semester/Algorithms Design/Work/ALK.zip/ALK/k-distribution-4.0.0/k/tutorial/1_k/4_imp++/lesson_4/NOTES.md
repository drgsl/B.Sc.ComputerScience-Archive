<!-- Copyright (c) 2010-2016 K Team. All Rights Reserved. -->

Make sure cells have the same indentation, which should use normal
spaces, not tabs.  Tabs look differently in different editors.

The tests here include all the imp and imp++ programs, but of course
the imp ones do not display any output, so their .out files are empty.
But this way we at least make sure we test that these programs
do not fail/crash and that nothing is output, so it is better that what
we used to have in K3.6.
