<!-- Copyright (c) 2012-2016 K Team. All Rights Reserved. -->

This approach leads to an incorrect type checker, in that programs which
lead to a runtime error will type.  See tricky-5 and/or variations of it.

Discuss monomorphic vs. polymorphic types and type inferencers.