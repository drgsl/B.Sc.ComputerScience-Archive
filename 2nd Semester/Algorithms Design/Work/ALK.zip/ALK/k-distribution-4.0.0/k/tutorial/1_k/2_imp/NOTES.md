<!-- Copyright (c) 2014-2016 K Team. All Rights Reserved. -->

* Revise the change of `S1 S2` into `S1:Stmt S2:Stmt`, if needed; only `S2`
really needs to be sorted.
