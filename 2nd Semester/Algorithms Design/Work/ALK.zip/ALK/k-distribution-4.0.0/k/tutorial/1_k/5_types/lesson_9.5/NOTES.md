<!-- Copyright (c) 2016 K Team. All Rights Reserved. -->

We have to test this as well; we need a test folder with a config.xml.
