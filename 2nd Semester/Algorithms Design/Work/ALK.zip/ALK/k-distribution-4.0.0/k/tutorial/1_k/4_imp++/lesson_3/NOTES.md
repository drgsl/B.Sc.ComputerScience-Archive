<!-- Copyright (c) 2016 K Team. All Rights Reserved. -->

We eliminated the superheat/supercool optimization.  Now we only need to use
the transition option.  So the video is out of synch now.
