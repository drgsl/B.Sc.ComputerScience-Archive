<!-- Copyright (c) 2014-2016 K Team. All Rights Reserved. -->

The README needs to be changed to reflect the fact that we now have a builtin
unification procedure.  We may even want to merge this lecture with the
next one, and eliminate the approach where we throw equalities on the computation.
This needs some more thinking, though, especialy on how to smoothly glue it
with Lesson 6, where we also use equalities.
