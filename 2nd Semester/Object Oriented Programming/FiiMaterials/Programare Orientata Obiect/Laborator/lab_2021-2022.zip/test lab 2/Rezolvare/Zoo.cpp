#include "Zoo.h";

using namespace std;

std::vector<Animal*> Zoo::GetFishes() {
	vector<Animal*> toReturn;

	for (auto i : animals)
		if (i->isAFish() == true) toReturn.push_back(i);

	return toReturn;
}

std::vector<Animal*> Zoo::GetBirds() {
	vector<Animal*> toReturn;

	for (auto i : animals)
		if (i->isABird() == true) toReturn.push_back(i);

	return toReturn;
}

std::vector<Animal*> Zoo::GetMammals() {
	vector<Animal*> toReturn;

	for (auto i : animals)
		if (i->isAMammal() == true) toReturn.push_back(i);

	return toReturn;
}

std::vector<Feline*> Zoo::GetFelines() {
	vector<Feline*> toReturn;

	for (auto i : animals)
		if (i->GetName() == "Tiger" || i->GetName()=="Lion") 
			toReturn.push_back((Feline*)(i));

	return toReturn;
}

int Zoo::GetTotalAnimals() {
	return animals.size();
}

void Zoo::operator+=(Animal* toInsert) {
	animals.push_back(toInsert);
}

bool Zoo::operator()(std::string toSearch) {
	for (auto i : animals)
		if (i->GetName() == toSearch) return true;
	return false;
}
