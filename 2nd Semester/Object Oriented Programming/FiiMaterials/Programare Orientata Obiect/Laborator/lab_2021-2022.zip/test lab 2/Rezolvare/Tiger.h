#pragma once
#include "Feline.h"
class Tiger :public Feline {
public:
	std::string GetName() {
		std::string toReturn = "Tiger";
		return toReturn;
	}
	bool isAFish() {
		return false;
	}
	bool isABird() {
		return false;
	}
	bool isAMammal() {
		return true;
	}
	int GetSpeed() {
		return 90;
	}
};