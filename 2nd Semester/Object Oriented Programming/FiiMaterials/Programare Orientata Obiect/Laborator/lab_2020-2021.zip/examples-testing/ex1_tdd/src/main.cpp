#include <iostream>
#include "gcd.h"

int main() {
    std::cout << "The first TDD Eexample" << std::endl;
    std::cout << "gcd(8,12): " << gcd(8,12) << std::endl;
    return 0;
}
