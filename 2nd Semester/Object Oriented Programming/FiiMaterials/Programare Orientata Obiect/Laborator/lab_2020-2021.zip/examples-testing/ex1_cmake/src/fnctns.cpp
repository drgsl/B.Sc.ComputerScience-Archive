int sqr(int x) {
    return x*x;
}

int inc2(int x) {
    return x + 2;
}