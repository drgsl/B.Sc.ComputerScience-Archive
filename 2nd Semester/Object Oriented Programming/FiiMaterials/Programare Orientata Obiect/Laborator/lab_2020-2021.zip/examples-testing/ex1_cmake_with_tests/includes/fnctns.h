//
// Created by Dorel Lucanu on 4/28/21.
//

#ifndef EX1_CMAKE_FNCTNS_H
#define EX1_CMAKE_FNCTNS_H

int sqr(int);

int inc2(int);

#endif //EX1_CMAKE_FNCTNS_H
