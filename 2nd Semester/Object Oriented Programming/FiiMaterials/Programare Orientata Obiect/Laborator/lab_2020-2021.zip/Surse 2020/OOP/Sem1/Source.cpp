#include "Math.h"

auto f()
{
	int a = 1;
	int b = 45;
	return (a, b);
}
int main()
{
	// std::cout << Math::Add("da", "nu");

	
	auto[a, b] = f();
	std::cout << a << ' ' << b;
	return 0;
}