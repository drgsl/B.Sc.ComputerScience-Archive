#pragma once

#include <iostream>

class Compare
{
public:
	virtual int CompareElements(void* e1, void* e2) = 0;
};

template<class T>
class ArrayIterator
{
private:
	int current; 
public:

	ArrayIterator(int value)
	{
		current = value;
	}

	ArrayIterator& operator++ ()
	{
		current++;
		return this;
	}

	ArrayIterator& operator-- ()
	{
		current--;
		return this;
	}

	bool operator= (ArrayIterator<T> & it)
	{
		current = it.current;
		return true;
	}

	bool operator!=(ArrayIterator<T> & it)
	{
		if (it.current != current) return true;
		return false;
	}
};

template <class T>
class Array 
{
private:

	T** list; // lista cu pointeri la obiecte de tipul T*

	int capacity; // dimensiunea listei de pointeri

	int size; // cate elemente sunt in lista

public:

	Array() // Lista nu e alocata, Capacity si Size = 0
	{
		capacity = 0;
		size = 0;
		list = nullptr;
	}

	Array(int cap)
	{
		if (cap <= 0)
			throw "Error: capacity cannot be below 1.";
		capacity = cap;
		size = 0;
		list = new T*[cap];
		for (int i = 0; i < cap; i++)
			list[i] = new T;
	}

	Array(const Array<T> &otherArray)
	{
		capacity = otherArray.capacity;
		size = otherArray.size;
		list = new T*[capacity];
		for (int i = 0; i < otherArray.capacity; i++)
		{
			list[i] = new T;
			*list[i] = *otherArray.list[i];
		}
	}

	~Array()
	{
		for (int i = 0; i < capacity; i++)
			delete list[i];
		delete[] list;
	}

	// arunca exceptie daca index este out of range
	T& operator[] (int index)
	{
		if (index < 0 || index >= capacity)
			throw "Error: index out of bounds. [1]";
		return *(list[index]);
	}


	// adauga un element de tipul T la sfarsitul listei si returneaza this
	const Array<T>& operator+=(const T &newElem) 
	{
		if (size == capacity)
			throw "Error: max capacity reached.";
		*(list[size++]) = newElem;
		return *this;
	}

	// adauga un element pe pozitia index, retureaza this. Daca index e invalid arunca o exceptie
	const Array<T>& Insert(int index, const T &newElem) 
	{
		if (index < 0 || index >= capacity)
			throw "Error: index out of bounds. [2]";
		if (index != 0 && index >= size)
			throw "Error: index can't be equal to size. [1]";

		for (int i = capacity - 1; i > index; i--)
			*list[i] = *list[i - 1];

		*(list[index]) = newElem;

		size = size == capacity ? size : size + 1;
		return *this;
	}

	// adauga o lista pe pozitia index, retureaza this. Daca index e invalid arunca o exceptie
	const Array<T>& Insert(int index, const Array<T> otherArray) 
	{
		if (otherArray.capacity > capacity)
			throw "Error: otherArray's capacity exceeds the list's capacity.";
		if (index + otherArray.capacity > capacity)
			throw "Error: index + otherArray's capacity exceeds the list's capacity.";
		if (index < 0 || index > capacity)
			throw "Error: index out of bounds. [3]";
		if (index != 0 && index >= size)
			throw "Error: index can't be equal to size. [2]";

		for (int i = capacity - 1; i > index; i--)
			if (i - otherArray.capacity >= index)
				*list[i] = *list[i - otherArray.capacity];
			else
				break;
		for (int i = index; i < otherArray.capacity; i++)
			*list[i] = *otherArray.list[i - index];

		size = size + otherArray.capacity > capacity ? capacity : size + otherArray.capacity;

		return *this;
	}

	// sterge un element de pe pozitia index, returneaza this. Daca index e invalid arunca o exceptie
	const Array<T>& Delete(int index)
	{
		if (index < 0 || index >= capacity)
			throw "Error: index out of bounds.";
		if (index != 0 && index >= size)
			throw "Error: index can't be equal to size.";
		if (size == 0)
			throw "Error: size is zero.";

		for (int i = index; i < size - 1; i++)
			*list[i] = *list[i + 1];
		size--;
	}


	bool operator=(const Array<T> &otherArray)
	{
		if (otherArray.size == 0)
			throw "Error: cannot copy empty list.";
		if (otherArray.capacity != capacity)
			throw "Error: cannot copy arrays with different capacities.";
		for (int i = 0; i < capacity; i++)
			*list[i] = *otherArray.list[i];
		size = otherArray.size;
		return true;
	}


	// sorteaza folosind comparatia intre elementele din T
	void Sort() 
	{
		T aux;
		bool ok;

		do
		{
			ok = true;
			for (int i = 0; i < size - 1; i++)
				if (*list[i] > *list[i + 1])
				{
					aux = *list[i];
					*list[i] = *list[i + 1];
					*list[i + 1] = aux;
					ok = false;
				}
		} while (!ok);
	}

	// sorteaza folosind o functie de comparatie
	void Sort(int(*compare)(const T&, const T&))
	{
		if (compare == nullptr)
			throw "Error: invalid compare function.";
		T aux;
		bool ok;

		do
		{
			ok = true;
			for (int i = 0; i < size - 1; i++)
				if (compare(*list[i], *list[i + 1]) < 0)
				{
					aux = *list[i];
					*list[i] = *list[i + 1];
					*list[i + 1] = aux;
					ok = false;
				}
		} while (!ok);
	}

	// sorteaza folosind un obiect de comparatie
	void Sort(Compare *comparator)
	{
		if (comparator == nullptr)
			throw "Error: comparator can't be a null pointer.";
		T aux;
		bool ok;

		do
		{
			ok = true;
			for (int i = 0; i < size - 1; i++)
				if (comparator->CompareElements(static_cast<void*>(list[i]), static_cast<void*>(list[i + 1])) > 0)
				{
					aux = *list[i];
					*list[i] = *list[i + 1];
					*list[i + 1] = aux;
					ok = false;
				}
		} while (!ok);
	}



	// functii de cautare - returneaza pozitia elementului sau -1 daca nu exista

	int BinarySearch(const T& elem) // cauta un element folosind binary search in Array
	{
		if (size == 0 || capacity == 0)
			throw "Error: array is empty.";

		int st = 0, dr = size - 1;
		int mij;
		while (st <= dr)
		{
			mij = (st + dr) / 2;
			if (*list[mij] == elem)
				return mij;
			if (*list[mij] < elem)
				st = mij + 1;
			else
				dr = mij - 1;
		}
		return -1;
	}

	int BinarySearch(const T& elem, int(*compare)(const T&, const T&)) //  cauta un element folosind binary search si o functie de comparatie
	{
		if (size == 0 || capacity == 0)
			throw "Error: array is empty.";

		int st = 0, dr = size - 1;
		int mij;
		while (st <= dr)
		{
			mij = (st + dr) / 2;
			if (compare(elem, *list[mij]) == 0)
				return mij;
			if (compare(elem, *list[mij]) > 0)	// elem > *list[mij]
				st = mij + 1;
			else
				dr = mij - 1;
		}
		return -1;
	}

	int BinarySearch(const T& elem, Compare *comparator) //  cauta un element folosind binary search si un comparator
	{
		if (size == 0 || capacity == 0)
			throw "Error: array is empty.";

		T elem_nonconst = elem;

		int st = 0, dr = size - 1;
		int mij;
		while (st <= dr)
		{
			mij = (st + dr) / 2;
			if (comparator->CompareElements(static_cast<void*>(list[mij]), static_cast<void*>(&elem_nonconst)) == 0)
				return mij;
			if (comparator->CompareElements(static_cast<void*>(list[mij]), static_cast<void*>(&elem_nonconst)) < 0)	// elem > *list[mij]
				st = mij + 1;
			else
				dr = mij - 1;
		}
		return -1;
	}


	int Find(const T& elem) // cauta un element in Array
	{
		// return BinarySearch(elem);

		for (int i = 0; i < size; i++)
			if (*list[i] == elem)
				return i;
		return -1;
	}

	int Find(const T& elem, int(*compare)(const T&, const T&)) // cauta un element folosind o functie de comparatie
	{
		for (int i = 0; i < size; i++)
			if (compare(elem, *list[i]) == 0)
				return i;
		return -1;
	}

	int Find(const T& elem, Compare *comparator) // cauta un element folosind un comparator
	{
		T elem_nonconst = elem;
		for (int i = 0; i < size; i++)
			if (comparator->CompareElements(static_cast<void*>(list[i]), static_cast<void*>(&elem_nonconst)) == 0)
				return i;
		return -1;
	}


	int GetSize()
	{
		return size;
	}

	int GetCapacity()
	{
		return capacity;
	}


	ArrayIterator<T> GetBeginIterator()
	{
		ArrayIterator it(0);
		return it;
	}

	ArrayIterator<T> GetEndIterator()
	{
		ArrayIterator it(size - 1);
		return it;
	}
};