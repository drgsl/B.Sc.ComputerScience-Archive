#include "Math.h"

int Math::Add(int x, int y) {
	return x + y;
}
int Math::Add(int x, int y, int z) {
	return x + y + z;
}
int Math::Add(double x, double y) {
	return int(x + y);
}
int Math::Add(double x, double y, double z) {
	return (x + y + z);
}
int Math::Mul(int x, int y) {
	return x * y;
}
int Math::Mul(int x, int y, int z) {
	return x * y * z;
}
int Math::Mul(double x, double y) {
	return int(x * y);
}
int Math::Mul(double x, double y, double z) {
	return (x * y * z);
}
int Math::Add(int count, ...)
{
	int sum = 0;

	va_list v;
	va_start(v, count);
	while (count)
	{
		sum += va_arg(v, int);
		--count;
	}
	va_end(v);
	return sum;
}
char* Math::Add(const char* a, const char* b)
{
	if (a == nullptr) return nullptr;
	if (b == nullptr) return nullptr;
	
	int n = strlen(a) + strlen(b);
	char* m =  (char*)(malloc(sizeof(char) * n));
	strcpy(m, a);
	strcat(m, b);
	return m;
}