#pragma once

enum Weather {
	Rain, Sunny, Storm
};