#pragma once
#include <cstring>
#include <iostream>

class MyVector {
	int* data;
	unsigned int size;
	unsigned int pos;
	void Resize();
public:
	MyVector(int);
	bool Add(int);
	bool Delete(int);
	void Iterate(void(*)(int &));
	void Filter(bool(*)(int &));
	void Print();
};