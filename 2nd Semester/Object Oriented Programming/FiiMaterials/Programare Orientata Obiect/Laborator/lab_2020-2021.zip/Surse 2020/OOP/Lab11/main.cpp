#include "Array.h"

class A : public Compare
{
public:
	int CompareElements(void* e1, void* e2)
	{
		int* e1_int = static_cast<int*>(e1);
		int* e2_int = static_cast<int*>(e2);
		return *e1_int - *e2_int;
	}
};

int main()
{
	try {
		Array<int> p(3);
		p += 10;
		p += 20;
		p += 30;
		Array<int> d(6);
		Array<int> l(6);
		Array<int> l2(6);

		d += 400;
		d += 300;
		d += 200;
		d += 100;

		d.Insert(0, p);

		d.Insert(0, 5);

		l = d;
		l2 = l;

		l2.Sort([](const int & x, const int & y) ->int { return x > y ? -1 : 1; });
		for (int i = 0; i < l2.GetSize(); i++)
			std::cout << l2[i] << ' ';
		std::cout << std::endl;

		A * a = new A();
		l.Sort(a);
		for (int i = 0; i < l.GetSize(); i++)
			std::cout << l[i] << ' ';
		std::cout << std::endl;

		std::cout << "400 se afla pe pozitia " << l.BinarySearch(400) << std::endl;
		std::cout << "300 se afla pe pozitia " << l.BinarySearch(300, a) << std::endl;
		std::cout << "500 se afla pe pozitia " << l.BinarySearch(500, a) << std::endl;
		std::cout << "10 se afla pe pozitia " << l.Find(10, a) << std::endl;

		d.Sort();
		for (int i = 0; i < d.GetSize(); i++)
			std::cout << d[i] << ' ';
		std::cout << std::endl;


	}
	catch (const char * errorCode)
	{
		std::cout << errorCode << std::endl;
	}

	return 0;
}
