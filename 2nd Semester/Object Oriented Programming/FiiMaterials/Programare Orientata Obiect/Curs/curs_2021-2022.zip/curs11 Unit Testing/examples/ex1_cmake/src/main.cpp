#include <iostream>
#include "../includes/fnctns.h"

int main () {
    std::cout << "The first CMake test" << std::endl;
    std::cout << sqr(inc2(3)) << std::endl;
    return 0;
}
