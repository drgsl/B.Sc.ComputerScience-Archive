//
// Created by Dorel Lucanu on 4/29/21.
//

int gcd(int a, int b) {
    //nothing
}
