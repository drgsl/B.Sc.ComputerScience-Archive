//
// Created by Dorel Lucanu on 4/29/21.
//

#ifndef EX1_TDD_GCD_H
#define EX1_TDD_GCD_H
int gcd(int, int);
#endif //EX1_TDD_GCD_H
