#E1:
t_test=function(esantion,miu0,alfa)
{
  n=length(esantion);
  sample_mean=mean(esantion);
  s=sd(esantion);
  se=s/sqrt(n);
  critical_t=qt(alfa,n-1);
  t_score=(sample_mean-miu0)/se;
  print(critical_t);
  print(t_score);
}

t_test(c(1.64,1.54,1.56,1.57,1.44,1.48,1.56),1.6,0.01)


# E4
camelia = function(alfa, sample1_mean, sample2_mean, n1, n2, sigma1, sigma2)
{
  m0=0
  combined_sigma = sqrt(sigma1^2/n1 + sigma2^2/n2)
  score_z = (sample1_mean-sample2_mean-m0)/combined_sigma
  if(sample1_mean-sample2_mean<m0)
  {
    print("Avem: Ipoteza asimetrica la stanga!")
    critical_z = qnorm(alfa, 0, 1);
    if(score_z<critical_z)
      print("Ipoteza nula este respinsa!")
    else
      print("Ipoteza nula este acceptata!")
  }
  else if(sample1_mean-sample2_mean>m0)
  {
    print("Avem: Ipoteza asimetrica la dreapta!")
    critical_z = qnorm(1-alfa, 0, 1);
    if(score_z>critical_z)
      print("Ipoteza nula este respinsa!")
    else
      print("Ipoteza nula este acceptata!")
  }
  else
  {
    print("Avem: Ipoteza simetrica!")
    critical_z = qnorm(1-alfa/2, 0, 1);
    if(abs(score_z)>abs(critical_z))
      print("Ipoteza nula este respinsa!")
    else
      print("Ipoteza nula este acceptata!")
  }
}

#3.1
camelia(0.75,0.78,155,150,15,14.5,0.01)

#E6:
E6=function()
{
  n1=197
  n2=204
  s1=0.6
  s2=0.9
  alfa=0.01
  F_scor=(s1^2)/(s2^2)
  Fs_stea=qf(alfa/2,n1-1,n2-1)
  Fd_stea=qf(1-alfa/2,n1-1,n2-1)
  
  if(F_scor<Fs_stea||F_scor>Fd_stea)
    print("Se respinge H0")
  else print("Nu putem respinge H0")
}
