#B2
number=function(x,i,n)
{
  j=i+n-1
  nr=0
  putere=1
  while(j>i-1)
  {
    nr=nr+putere*x[j]
    putere=putere*2
    j=j-1
  }
  return (nr)
}

lasvecegas=function()
{
  x=c(1,1,0,1)
  y=c(0,1,1,0,1,0,1,1,0,0,1,0,0)
  Lx=4
  Ly=13
  a=Lx^2*Ly*log2(Lx^2*Ly)
  vec=Primes(1601)
  l=length(vec)
  i=sample(1:l,1)
  p=vec[i]
  r=number(x,1,Lx)%%p
  for (i in 1:(Ly-Lx+1))
  {
    if (number(y,i,Lx)%%p==r & number(y,i,Lx)==number(x,1,Lx))
    {
      return(i);
    }
  }
  return (-1);
}

ok=-1
for (i in 1:10)
{
  if(lasvecegas()!=-1) ok=1
}
if (ok==1) print("da")
if (ok==-1) print("?")

