# D1
sodiu=function(n,medie,alfa,sig)
{
  sigma=sqrt(sig);
  crit=qnorm(1-alfa/2,0,1);
  a=medie-crit*sigma/sqrt(n);
  b=medie+crit*sigma/sqrt(n);
  interval=c(a,b);
  return (interval);
}

sodiu(8,140,0.05,10)

# D3
companie=function(alfa,n,succ,p)
{
  prim=succ/n;
  score=(prim-p)/sqrt(p*(1-p)/n);
  return (score);
}

scor=companie(0.01,100,32,0.3)
crit=qnorm(0.99,0,1)
scor
crit

scor=companie(0.05,100,32,0.3)
crit=qnorm(0.95,0,1)
scor
crit
