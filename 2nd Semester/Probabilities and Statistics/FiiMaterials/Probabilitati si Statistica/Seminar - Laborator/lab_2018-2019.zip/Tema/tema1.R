#A1

k=19
probab=0.7
m=6
p=0.3
n=16

x=dbinom(1:k,n,p)
barplot(x,space=0.5,col="green")

y=dpois(1:k,5)
barplot(y,space=1,col="grey")

z=dgeom(1:k,probab)
barplot(z,space=1,col="yellow")

#A2

esantion=c(79,71,89,57,76,64,82,82,67,80,81,65,73,79,79,60,58,83,74,68,78,80,78,81,76,65,70,76,58,82,59,73,72,79,87,63,74,90,69,70,83,76,61,66,71,60,57,81,57,65,81,78,77,81,81,63,71,66,56,62,75,64,74,74,70,71,56,69,63,72,81,54,72,91,92)

summ=summary(esantion)
quant=c(quantile(esantion))

med=medie(esantion)
esantion_2=vector()
DS=ds(esantion)

k=0
for(i in 1:45)
  if(esantion[i]>=med-2*DS & esantion[i]<=med+2*DS)
  {
    k=k+1
    esantion_2[k]=esantion[k]
  }
print(esantion_2) 

interval=seq(40,100,10)
hist(esantion,breaks=interval,right=F,freq=T,col="yellow")