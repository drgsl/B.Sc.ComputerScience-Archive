#c1

volumVas = function(N)
{
  
  a = 2;
  nr = 0;
  
  for (i in 1:N)
  {
    u = runif(1, -sqrt(a), sqrt(a))
    v = runif(1, -sqrt(a), sqrt(a))
    w = runif(1, -a, a)
    
    wReal = u*u + v*v;
    
    if (w > wReal){
      nr = nr + 1;
    }
  }
  
  volumCuboid = (2*sqrt(a)*(2*sqrt(a))*(2*a))
  
  volumVas = volumCuboid*nr/N;
  volumReal = pi*a*a/2;
  
  eroareAbs = abs(volumVas-volumReal);
  eroareRel = abs(volumVas-volumReal) / abs(volumReal);
  
  print(eroareAbs);
  print(volumReal);
  print(eroareRel);
  
  return (volumVas);
}


volumVas(10000)
volumVas(20000)
volumVas(50000)

#c2

arieTriunghi = function (n)
{
  nr = 0
  for (i in 1:n)
  {
    y = runif(1, 0, 1)
    x = runif(1, 0, 1.5)
    if (x - 2  * y  <= 0 && 2*x - 3*y >= 0 && 3*x + 2*y <= 6)
      nr = nr + 1
  }
  return (nr/n*1.5)
}
arieTriunghi(10000)
arieTriunghi(50000)

#c3
integrala1 = function(N)
{
  suma=0
  for(i in 1:N)
  {
    u = runif(1, 0, pi/3)
    suma = suma + sin(u)^3 + cos(u)^3
  }
  k = (sqrt(3^5)+5)/24
  rez = pi/3 * suma/N 
  return (c(rez, 100 * abs(rez-k)/k))
}

integrala2 = function(alfa, N)
{
  suma = 0;
  for (i in 1:N)
  {
    u = rexp(1, alfa);
    suma = suma + 1/(2*u*u + 1)/(alfa*exp(-alfa*u));
  }
  return (c(suma/N, 100 *abs(suma/N - pi/2/sqrt(2))/pi/2/sqrt(2)));
}

integrala1(100)
integrala2(100,50)

#c4

distr = function()
{
  n = runif(1, 0, 1)
  TOT = 0
  if (n <= 0.35)
  {
    TOT = TOT + rgamma(1, 6, 4)
  }else{
    TOT = TOT + rgamma(1, 5, 3)
  }
  TOT = TOT + rexp(1,1)
}

Web = function (N)
{
  sum = 0
  for (i in 1:N)
  {
    sum = sum + distr()
  }
  return (sum/N * 100)
}

#c6
foc=function()
{
  padure=matrix(0,nrow=40,ncol=40,byrow=TRUE)
  padure[40,40]=1
  nrCopaci=1
  zi=1
  copaciArsi=1
  while (copaciArsi!=0)
  {
    copaciArsi=0
    i=1;
    j=1;
    for (i in 1:40)
    {
      for (j in 1:40)
      {
        if(f[i,j]==zi)
        {
          west=runif(1,0,1)
          if (west<=0.7 && j>1 && padure[i,j-1]==0) 
          {
            
            copaciArsi=copaciArsi+1;
            f[i,j-1]=(zi+1)
          }
          est=runif(1,0,1)
          if (est<=0.4 && j<40 && padure[i,j+1]==0) 
          {
            copaciArsi=copaciArsi+1;
            f[i,j+1]=(zi+1)
          }
          nord=runif(1,0,1)
          if (nord<=0.4 && i>1 && padure[i-1,j]==0) 
          {
            copaciArsi=copaciArsi+1;
            f[i-1,j]=(zi+1)
          }
          
          
          sud=runif(1,0,1)
          if (sud<=0.2 && i<40 && padure[i+1,j]==0) 
          {
            copaciArsi=copaciArsi+1;
            f[i+1,j]=(zi+1)
          }
        }
      }
    }
    zi=zi+1
    nrCopaci=nrCopaci+copaciArsi
    
  }
  return (nrCopaci)
}

N_C=0
N=100
for (i in 1:N)
{
  if (foc()>=400) N_C=N_C+1
}
print(N_C/N)




