#exercitiul1

ex1=function(v)
{
  v=c(46, 33, 39, 37, 46, 30, 48, 32, 49, 35, 30, 48)
  a=min(v)
  b=max(v)
  c=sum(v)
  d=length (v[v<40])
  e=length(v[v>35])/length(v)*100

  return (list(a,b,c,d,e))
}

ex1()

#ex2

ex2a=function(x)
{
  v=x/sum(x)
  return (v)
}
x=c(1,2,3,4)
ex2a(x)

ex2b=function(x)
{
  v=(x-min(x))/max(x)
  return(v)
}
x=c(1,2,3,4)
ex2b(x)

#ex3
x=scan('fisier.txt')
ex2a(x)

# Exercitiul 4
densitate = function(n, p)
{
  return(barplot(dbinom(0:n, n, p),
                 main = 'Grafic',
                 col = 'green'))
}
densitate(25, 0.3)

#ex5
   pmax=function(n,p)
   {
     return (max(dbinom(0:n,n,p)))
   }
   pmax(25,0.3)

#ex6
   geometric=function(n,p)
   {
     return (barplot(dgeom(0:n,p),main="Grafic",col="blue"))
   }
   geometric(5,0.4)

#ex7
   ex7=function(file)
   {
     file = read.table('document.txt',header= TRUE)
    x = file[['AA']]
    y = file[['BB']]
    plot(x,y,type='h',col='black',lwd=10)
   }
ex7()



