#1
ztest=function(population_mean,sample_mean,sigma,alfa,n,tiptest)
{

  Zscor=(population_mean - sample_mean)/(sigma/sqrt(n))
  if(tiptest==-1)
  {
    Zcritic=qnorm(alfa,0,1) #STG
    if(Zscor > Zcritic)
      print('H0')
    else
      print('Ha')
  }
  else
    if(tiptest==1) #DRP
    {
      Zcritic=qnorm(1-alfa)
      if(Zscor < Zcritic)
        print('H0')
      else
        print('Ha')
    }
  else
  {   
    Zcritic=qnorm(1-alfa/2,0,1) #SIMETRIC
    if(abs(Zscor) < abs(Zcritic))
      print('H0')
    else
      print('Ha')
  }
}
ztest(88,90,12,0.05,49,-1)


#3
ttest=function(population_mean,sample_mean,s,alfa,n,tiptest)
{
 
  tscor=(population_mean - sample_mean)/(s/sqrt(n))
  if(tiptest==-1) #STG
  {
    tcritic=qt(alfa,n-1)
    if(tscor > tcritic)
      print('H0')
    else
      print('Ha')
  }
  else
    if(tiptest==1) #DRP
    {
      tcritic=qnorm(1-alfa,n-1)
      if(tscor < tcritic)
        print('H0')
      else
        print('Ha')
    }
  else
  {
    tcritic=qnorm(1-alfa/2) #SIMETRIC
    if(abs(tscor) < abs(tcritic))
      print('H0')
    else
      print('Ha')
  }
  
  
}
ttest(11.9,11.4,0.25,0.01,100,1)


Zdiferenta=function(n1,x1,sigma1,n2,x2,sigma2,alfa,tiptest)
{

  Zscor=(x1-x2)/(sqrt(sigma1^2/n1+sigma2^2/n2))
  
  if(tiptest==-1)
  {
    Zcritic=qnorm(alfa,0,1) #STG
    if(Zscor > Zcritic)
      print('H0')
    else
      print('Ha')
  }
  else
    if(tiptest==0) #SIM
    {
      Zcritic=qnorm(1-alfa/2,0,1)
      if(abs(Zscor) < abs(Zcritic))
        print('H0')
      else
        print('Ha')
    }
  else #DRP
  {
    Zcritic=qnorm(1-alfa,0,1) #DRP
    if(Zscor < Zcritic)
      print('H0')
    else
      print('Ha')
  }
}

Zdiferenta(80,160,3.24,70,155,2.25,0.01,0)


Ftest=function(n1,s1,n2,s2,alfa,tiptest)
{

  Fscor=s1^2/s2^2
  
  if(tiptest==-1)
  {
    Fs=qf(alfa/2,n1-1,n2-1)
    if(Fscor > Fs)
      print('H0')
    else
      print('Ha')
    
  }
  else
    if(tiptest==0)
    {
      Fs=qf(alfa/2,n1-1,n2-1)
      Fd=qf(1-alfa/2,n1-1,n2-1)
      if(Fscor>=Fs && Fscor<=Fd)
        print('H0')
      else
        print('Ha')
    }
  else
  {
    Fd=qf(1-alfa/2,n1-1,n2-1)
    if(Fscor<Fd)
      print('H0')
    else
      print('Ha')
  }
}
Ftest(120,5.05,135,5.44,0.01,0)