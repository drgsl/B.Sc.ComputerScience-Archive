#1.1
#ztest=function(population_mean,sampple_mean,sigma,alfa,n,tiptest)
  
  ztest <- function(alfa, population_mean, sample_mean, n, sigma,tiptest)
  {
    z_score = (sample_mean - population_mean)/(sigma/sqrt(n))
    if(tiptest="stg")
    {
      zcritic=qnorm(alfa)
      if (z_score>z_critic)
        
      print("se accepta ipoteza nula")
      else
        print("se respinge ipoteza nula")
      
    }
    else
      if(tiptest="dr")
      {
        if(z_score<z_critic)
          print("se accepta ipoteza nula")
        else
          print("se respinge ipoteza nula")
      }
  
   
    print(z_critic)
    z_score
  }
  
  med_pop_disp_cunosc(0.05, 810, 816, 200, 50)
  
  #2
  t_test1 = function(file)
  {
    x = scan(file);
    return(x)
  }
  
  med_pop_disp_nec = function(alfa, n, population_mean, sample_mean, x, file)
  {
    if(length(x) == 1)
      x = t_test1(file);
    s = sd(x);
    se = s/sqrt(n);
    t_score = (sample_mean - population_mean)/se;
    if(sample_mean<population_mean)
    {
      critical_t = qt(alfa, n - 1)
      if(t_score<critical_t)
        print("Ipoteza nula este respinsa")
      else
        print("Ipoteza nula nu poate fi respinsa!")
    }
    else if(sample_mean>population_mean)
    {
      critical_t = qt(1 - alfa, n - 1);
      if(t_score>critical_t)
        print("Ipoteza nula este respinsa")
      else
        print("Ipoteza nula nu poate fi respinsa!")
    }
    else
    {
      critical_t = qt(1-alfa/2, n-1)
      if(abs(t_score)>abs(critical_t))
        print("Ipoteza nula este respinsa")
      else
        print("Ipoteza nula nu poate fi respinsa!")
    }
  }
  
  #2.2
  x = c(36, 32, 28, 33, 41, 28, 31, 26, 29, 34);
  med_pop_disp_nec(0.01, length(x), 34, mean(x), x)
  
  #2.4
  x = t_test1("history.txt")
  med_pop_disp_nec(0.01, length(x), 80, mean(x), x)
  
  #3
  diferenta_mediilor_disp_cunosc = function(alfa, sample1_mean, sample2_mean, n1, n2, sigma1, sigma2)
  {
    m0=0
    combined_sigma = sqrt(sigma1^2/n1 + sigma2^2/n2)
    score_z = (sample1_mean-sample2_mean-m0)/combined_sigma
    if(sample1_mean-sample2_mean<m0)
    {
      print("Avem: Ipoteza asimetrica la stanga!")
      critical_z = qnorm(alfa, 0, 1);
      if(score_z<critical_z)
        print("Ipoteza nula este respinsa!")
      else
        print("Ipoteza nula este acceptata!")
    }
    else if(sample1_mean-sample2_mean>m0)
    {
      print("Avem: Ipoteza asimetrica la dreapta!")
      critical_z = qnorm(1-alfa, 0, 1);
      if(score_z>critical_z)
        print("Ipoteza nula este respinsa!")
      else
        print("Ipoteza nula este acceptata!")
    }
    else
    {
      print("Avem: Ipoteza simetrica!")
      critical_z = qnorm(1-alfa/2, 0, 1);
      if(abs(score_z)>abs(critical_z))
        print("Ipoteza nula este respinsa!")
      else
        print("Ipoteza nula este acceptata!")
    }
  }
  
  #3.1
  diferenta_mediilor_disp_cunosc(0.05, 48, 47, 100, 100, 4, 3)
  
  #3.2
  diferenta_mediilor_disp_cunosc(0.01, 160, 155, 80, 70, 3.24, 2.25)
  
  #3.3
  diferenta_mediilor_disp_cunosc(0.01, 22.8, 23.3, 100, 100, 1.3, 1.9)
  
  #4.1
  Inferenta_asupra_disp = function(alfa, n1, n2, s1, s2)
  {
    critical_F_s = qf(alfa/2, n1-1, n2-1)
    critical_F_d = qf(1-alfa/2, n1-2, n2-1)
    score_F = sqrt(s1)/sqrt(s2)
    if(score_F<critical_F_s || score_F>critical_F_d)
      print("Ipoteza nula este respinsa!")
    else
      print("Nu exista suficiente dovezi pentru a respinge ipoteza nula!")
  }
  
  Inferenta_asupra_disp(0.01, 120, 135, 5.05, 5.44)
  
  
  