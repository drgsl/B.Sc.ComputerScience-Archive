#1
normal_density=function(limit,miu,disp)
{
  sigma=sqrt(disp)
  t=seq(-limit,limit,length=400)
  f=( 1/sqrt(2*pi)*exp(-t^2/2))
  plot(t,f,type='l',lwd=5,col='blue')
}
normal_density(60,5,10)

#2
det_selection_mean <- function(filename) {
  x = scan(filename)
  med = mean(x)
  med
}

det_selection_mean("history.txt")

#3
zconfidence_interval <- function(niv_inc, medie_sel, esan, disp) {
  alfa = niv_inc
  selection_mean = medie_sel
  n = esan
  sigma = sqrt(disp)
  critical_z = qnorm(1-alfa/2, mean = 0, sd = 1)
  a = selection_mean - critical_z * sigma / sqrt(n)
  b = selection_mean + critical_z * sigma / sqrt(n)
  interval = c(a,b)
  interval
}
zconfidence_interval(0.1, 20, 100, 9)

#3.2
zconfidence_interval(0.1, 67.53, 25, 100)

#3.4
zconfidence_interval(0.01, 1280, 100, 140^2)


#4
t_conf_interval <- function(niv_inc, medie_sel, esan, deviatie) {
  alfa = niv_inc
  selection_mean = medie_sel
  n = esan
  s = deviatie
  se = s/sqrt(n)
  critical_t = qt(1-alfa/2, n-1)
  a = selection_mean - critical_t * se
  b = selection_mean + critical_t * se
  interval = c(a,b)
  interval
}

#4.2
t_conf_interval(0.01, 44.65, 196, sqrt(2.25))

#4.5
x=c(12,11,12,10,11,12,13,12,11,11,13,14,10)
t_conf_interval( 0.1, mean(x), length(x), sd(x))
t_conf_interval(0.05, mean(x), length(x), sd(x))
t_conf_interval(0.01, mean(x), length(x), sd(x))

#5
test_proportion <- function(alfa, n, succese, p0,tiptest)
{
  p_prim = succese/n
  if(p_prim>p0)
    print("Ipoteza asimetrica la dreapta")
  else
    print("Ipoteza asimetrica la stanga")
  z_score = (p_prim - p0) / sqrt(p0*(1-p0)/n)
  z_critical = qnorm(1 - alfa, 0, 1)
  print(z_score)
  print(z_critical)
  if(z_score<z_critical)
    print("Scorul testului este mai mic decat valoarea critica")
  else
    print("Scorul testului este mai mare decat valoarea critica")
  if(z_score<z_critical)
  {
    if(p_prim<p0)
      print("! Ipoteza nula este respinsa !") 
    else
      print("! nu exista suficiente dovezi pentru a respinge ipoteza nula !")
  }
  if(z_score>z_critical)
  {
    if(p_prim>p0)
      print("! Ipoteza nula este respinsa !")
    else
      print("! nu exista suficiente dovezi pentru a respinge ipoteza nula !")
  }
}

test_proportion(0.01, 100, 63, 0.6)

#5.2
test_proportion(0.05,150,20,0.1)

#5.3
test_proportion(0.01,42,17,0.25)