#ex rezolvat
#se genereaza o val aleatoare din intervalul [-1 1]

disc_area = function(N) {
  N_C = 0;
  for(i in 1:N) {
    x = runif(1, -1, 1);
    y = runif(1, -1, 1);
    if(x*x + y*y <= 1)
      N_C = N_C + 1;
  }
  return(4*N_C/N); 
}

#disc_area(10000)

sphere_area = function(N) {
  N_C = 0;
  for(i in 1:N) {
    x = runif(1, -1, 1);
    y = runif(1, -1, 1);
    z = runif(1, -1, 1);
    if(x*x + y*y + z*z <= 1)
      N_C = N_C + 1;
  }
  return(9*N_C/N); 
}

MC_integration = function(N) {
  sum = 0;
  for(i in 1:N) {
    u = runif(1, 0, 10);
    sum = sum + exp(-u*u/2);
  }
  return(10*sum/N);
}


calcSin = function(N){
  count = 0;
  for(i in 1:N){
    u = runif(1,0,pi);
    count = count + sin(u)*sin(u);
  }
  return(pi*count/N)
}


Nr_days = function() {
  nr_days = 1;
  last_errors = c(27, 31);
  nr_errors = 27;
  while(nr_errors > 0) {
    lambda = min(last_errors);
    nr_errors = rpois(1, lambda);
    last_errors = c(nr_errors, last_errors[1]) ;
    nr_days = nr_days + 1;
  }
  return(nr_days);
}

MC_nr_days = function(N) {
  s = 0;
  for(i in 1:N)
    s = s + Nr_days();
  return(s/N);
}


Nr_days2 = function() {
  nr_days = 1;
  last_errors = c(13, 15, 9);
  nr_errors = 13;
  while(nr_errors > 0) {
    lambda = mean(last_errors);
    nr_errors = rpois(1, lambda);
    last_errors = c(nr_errors, last_errors[1]) ;
    nr_days = nr_days + 1;
  }
  return(nr_days);
}

calcRad = function(N){
  count = 0;
  for(i in 1:N){
    u = runif(1,0,1);
    count = count + (1/sqrt(1-u*u));
  }
  return(count/N)
}

#I ex2
parab=function(N)
{
  nr_per=0
  for(i in 1:N)
  {
    x=runif(1,-1,2)
    y=runif(1,0,2)
    if(y<=(-2*x*x+5*x-2))
      nr_per=nr_per+1
  }
  return(9*nr_per/N)
}

calc_ln = function(N){
  count = 0;
  for(i in 1:N){
    x = rexp(1,1)
    count = count + (1/(4*(x*x)-1));
  }
  return(x*count/N)
}

MC_integr_2 = function(N){
  sum = 0
  for(i in 1:N){
    u = rexp(1,1)
    sum = sum + exp(-2*u*u)
  }
  return(sum/N)
}

nrSIM = function(N){
  count = 0.0
  for(i in 1:N){
    u = rgeom(1,0.3)
    w = rgeom(1,0.5)
    if(u < w*w)
      count = count + 1.0
  }
  return(count/N)
}