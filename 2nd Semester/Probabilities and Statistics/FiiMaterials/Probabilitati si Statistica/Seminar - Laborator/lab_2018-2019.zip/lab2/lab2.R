ex1.1=function(x)
{
  v=stem(x);
}
x=scan("sample1.txt")
ex1.1(x)

ex1.2=function(x)
{
  rate=x[['rate']]
  hist(rate,breaks=c(0,4,6,8,10,12,14,30),freq=T, right=T,sight=T,col='red') #freq=T => interval inchis la dreapta
}
x=read.csv("unemploy2012.csv",sep=";",header=T)
ex1.2(x)

ex1.3=function(x)
{
  intervale_b=7
  speranta_b=x[['male']]
  hist(speranta_b,breaks=intervale_b,right=F,col="blue")
  intervale_f=7
  speranta_f=x[['female']]
  hist(speranta_f,breaks=intervale_f,right=F,col="red")
}
x=read.csv("life_expect.csv",sep=",",header=T)
ex1.3(x)

ex2.1=function(x)
{
  v1=mean(x)
  v2=median(x)
  return (list(v1,v2))
}
x=scan("sample1.txt")
ex2.1(x)

ex2.2=function(x)
{
  speranta_b=x[['male']]
  spernata_f=x[['female']]
  v1=mean(speranta_b)
  w1=median(speranta_b)
  v2=mean(spernata_f)
  w2=median(spernata_f)
  return (list(v1,w1,v2,w2))
}
x=read.csv("life_expect.csv",sep=",",header=T)
ex2.2(x)

ex3_1=function(x)
{
  j=0
  m=mean(x)
  s=sd(x)
  new_sample=vector()
  for(i in 1 : length(x))
  
    if(x[i] <= m - 2*s | x[i] >= m + 2*s) 
      {
       j = j + 1
       new_sample[j] = x[i]
    }
    new_sample
}
x=scan("sample1.txt")
ex3_1(x)

ex3_2=function(x)
{
  j=0
  q1=as.vector(quantile(x))[1]
  q3=as.vector(quantile(x))[3]
  dif=q3-q1
  new_sample=vector()
  
  for(i in 1 : length(x))
    
    if(x[i] <= q1-1.5*dif | x[i] >= q3+1.5*dif) 
    {
      j = j + 1
      new_sample[j] = x[i]
    }
  new_sample
}
x=scan("sample1.txt")
ex3_2(x)














