################################ 1
ex1 = function(x) {
  print(max(x))
  print(min(x))
  print(median(x))
  print(sum(x))
  print(min(x) / max(x))
  
  nr = 0
  for(n in x) {
    if (n >= 40) {
      nr = nr + 1
    }
  }
  
  print(nr)
  print((1 - nr / 12) * 100)
  
}

x = scan()
# 46 33 39 37 46 30 48 32 49 35 30 48
ex1(x)


################################ 2
ex2a = function(x) {
  s = sum(x)
  y = vector()
  
  for(i in 1:length(x)) {
    y[i] = x[i] / s
  }
  return (y)
}

ex2b = function(x) {
  mi = min(x)
  ma = max(x)

  y = vector();
  
  for (i in 1:length(x)) {
    y[i] = (x[i] - mi) / ma
  }
  return (y)
}

ex2c = function(x) {
  y = vector()
  n = length(x)
  for (i in 1:length(x) - 1) {
    y[i] = sum(x[1:i]) / sum(x[(i + 1):(n - 1)])
  }
  return (y)
}

ex2d = function(x) {
  y = vector()
  n = length(x)
  
  for (i in 1:n - 1) {
    y[i] = max(x[1:i]) / min(x[i+1:n]);
  }
  return (y);
}

x = scan()
# 46 33 39 37 46 30 48 32 49 35 30 48
ex2a(x)
ex2b(x)
ex2c(x)
ex2d(x)


################################ 3
x = scan("input.txt")


################################ 4
ex4 = function(n, p) {
  y = dbinom(0:n, n, p)
  barplot(0:n, y, space = 0, col = "red")
}

ex4(18, 0.25)
ex4(40, 0.5)
ex4(30, 0.8)

################################ 5
ex5a = function(n, p) {
  x = dbinom(0:n, n, p)
  return (max(x))
}

ex5b = function(n, p, k) {
  x = dbinom(0:n, n, p)
  return (sum(x[1:k]))
}

ex5c = function(n, p, k, m) {
  x = dbinom(0:n, n, p)
  return (sum(x[(k + 1):(p + 1)]));
}

ex5a(18, 0.25)
ex5b(40, 0.5, 10)
ex5c(30, 0.8, 15, 20)

################################ 6
ex6a = function(p, n) {
  y = dgeom(0:n, p)
  return (sum(y))
}

ex6b = function(p, m) {
  return (1 - ex6a(p, m))
}

ex6a(0.1, 10)
ex6b(0.1, 10)


################################ 7
ex7 = function(p, n) {
  y = dgeom(0:n, p)
  barplot(y, 1:n, space = 0, xlab = "X");
}

ex7(0.2, 30)


################################ 8
ex8a = function(lambda, n) {
  y = dpois(0:n, lambda)
  return (sum(y))
}

ex8b = function(lambda, n) {
  y = dpois(0:n, lambda)
  return (1 - sum(y))
}

ex8a(0.5, 10)
ex8b(0.5, 10)


################################ 9
ex9 = function(lambda, n) {
  y = dpois(0:n, lambda)
  barplot(y, 0:n)
}

ex9(0.5, 10)

################################ 10
readVectors = function(name) {
  z = read.table(name, header=T);
  x = z[['AA']]
  y = z[['BB']]
}

ex10ab = function() {
  z = read.table(name, header=T);
  x = z[['AA']]
  y = z[['BB']]
  ex10q(name)
  plot(x, y, type="b");
  return (x * y)
}

ex10c = function() {
  z = read.table(name, header=T);
  x = z[['AA']]
  y = z[['BB']]
  z = vector()
  s = (x - y) ^ 2
  for(i in 1:length(x)) {
    z[i] = abs(x[i] - y[i]) / s;
  }
  return (z)
}

readVectors("input.txt")
ex10ab("input.txt")
ex10c("input.txt")

