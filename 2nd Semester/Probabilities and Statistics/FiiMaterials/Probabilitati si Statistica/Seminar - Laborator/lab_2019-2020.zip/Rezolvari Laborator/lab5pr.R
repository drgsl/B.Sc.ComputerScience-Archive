#Statistica inferentiala

# Legea normala, reprezentare grafica

t = seq(-6, 6, length = 400)
f = 1/sqrt(2*pi)*exp(-t^2/2)
plot(t, f, type = "l", lwd = 1)

normal_density=function(limit){
t = seq(-limit, limit, length = 400)
f = 1/sqrt(2*pi)*exp(-t^2/2)
plot(t, f, type = "l", lwd = 1,col="blue")
}
normal_density(6)

#Exercitiul I.1
normal=function(mu,var,limit){
  t=seq(-limit,limit,length = 400)
  f=1/(sqrt(var)*sqrt(2*pi))*exp(-(t-mu)^2/(2*var))
  plot(t,f,type= "l",lwd=2,main="Normal density")
#lwd=2 - grosimea liniei
  }
normal(0,1,6)

#II. Estimarea mediei unei populatii: 
# Media de selectie
selection_mean = function(filename){
  x = scan(filename);
  m = mean(x)
  return(m)
}
selection_mean("history.txt")

#III. Intervale de incredere pentru media unei 
#populatii cu dispersia cunoscuta

#z_star = -qnorm (alpha/2, mean = 0, sd = 1) 
#sau 
#z_star = qnorm (1 â alpha/2, mean = 0, sd = 1)

#Exercitiu rezolvat. 

#Durata vietii unui tip de baterie urmeaza
#cu aproximatie o lege normala cu dispersia de 9 ore. 
#Pentru un esantion de 100 de baterii se masoara o 
# medie de viata de 20 de ore. 
# Sa se determine un interval de incredere de 
#90% pentru media de viata a intregii populatii.

#100%-90%=0.1
alfa = 0.1
#media de viata
sample_mean = 20
#dimensiunea esantionului
n = 100
# sd
sigma = sqrt(9)
critical_z = qnorm(1 - alfa/2, 0, 1)
#critical_z=-qnorm (alfa/2, mean = 0, sd = 1) 
a = sample_mean - critical_z*sigma/sqrt(n)
b = sample_mean + critical_z*sigma/sqrt(n)
interval = c(a, b)
print("Intervalul de incredere")
interval

#III.1
z_confidence_interval=function(n,alfa,xbar,var){
  sigma=sqrt(var)
  critical_z = qnorm(1 - alfa/2, 0, 1)
  #critical_z=-qnorm (alfa/2, mean = 0, sd = 1) 
  a = xbar - critical_z*sigma/sqrt(n)
  b = xbar + critical_z*sigma/sqrt(n)
  interval = c(a, b)
  print("Intervalul de incredere")
  return(interval)
}
z_confidence_interval(100,0.1,20,9)

#III.2
alpha=0.1
var=100
n=25
xbar=67.53
z_confidence_interval(25,0.1,67.53,100)

#III.3
var=0.5*0.5
n=50
#xbar=media
xbar=5
alfa=1-0.95
z_confidence_interval(50,0.05,5,0.25)

#III.4

n=100
xbar=1280
#dev standard=140
var=140^2
alfa=1-0.99
z_confidence_interval(100,0.01,1280,140^2)

#III.5
n=35
xbar=60
s=5
var=25
alfa1=1-0.9
alfa2=1-0.95
alfa3=1-0.99
# 90%
z_confidence_interval(35,alfa1,60,25)
#[1] "Intervalul de incredere"
#[1] 58.60984 61.39016

# 95%
z_confidence_interval(35,alfa2,60,25)
#[1] "Intervalul de incredere"
#[1] 58.34353 61.65647

# 99%
z_confidence_interval(35,alfa3,60,25)
#[1] "Intervalul de incredere"
#[1] 57.82303 62.17697


#Intervalul de incredere pentru 99% > int de incredere pentru 95%
#Motiv:TBA
 

#III.6 
  
z_confidence_fisier=function(filename,alfa){
  x=scan(filename)
  n=length(x)
  xbar=mean(x)
  sigma=sd(x)
  critical_z = qnorm(1 - alfa/2, 0, 1)
  #critical_z=-qnorm (alfa/2, mean = 0, sd = 1) 
  a = xbar - critical_z*sigma/sqrt(n)
  b = xbar + critical_z*sigma/sqrt(n)
  interval = c(a, b)
  cat("Intervalul de incredere pentru",(1-alfa)*100, "% :")
  return(interval)
}
z_confidence_fisier("history.txt",0.05)


#IV. Intervale de incredere pentru media unei populatii cu dispersia necunoscuta

#Exercitiu rezolvat
n=60
sample_mean=3.3
s=0.4
alfa=0.05
se = s/sqrt(n)
critical_t = qt(1 - alfa/2, n - 1)
a = sample_mean - critical_t*se
b = sample_mean + critical_t*se
interval = c(a, b)
print("Interval de incredere")
interval

#Exercitii propuse

#IV.1
t_conf_interval=function(n,sample_mean,alfa,s){
  se = s/sqrt(n)
  critical_t = qt(1 - alfa/2, n - 1)
  a = sample_mean - critical_t*se
  b = sample_mean + critical_t*se
  interval = c(a, b)
  print("Interval de incredere")
  return(interval)
}
t_conf_interval(60,3.3,0.05,0.4)

#IV.2
n=196
sample_mean=44.65
var=2.25
s=sqrt(2.25)
alfa=0.01
t_conf_interval(196,44.65,0.01,sqrt(2.25))

#IV.3
n=49
#media nivelului de zahar
sample_mean=12
s=1.75
alfa1=0.05
alfa2=0.01
#("Intervalul de incredere pentru 99%")
t_conf_interval(49,12,0.01,1.75)
#"Intervalul de incredere pentru 95%"
t_conf_interval(49,12,0.05,1.75)

#punctul b
mean_1=13.5
s=1.25
alfa=0.05
t_conf_interval(49,13.5,0.05,1.25)

#IV.4
t_conf_interval_fisier=function(filename,alfa){
  x=scan(filename)
  n=length(x)
  s=sd(x)
  sample_mean=mean(x)
  se = s/sqrt(n)
  critical_t = qt(1 - alfa/2, n - 1)
  a = sample_mean - critical_t*se
  b = sample_mean + critical_t*se
  interval = c(a, b)
  print("Interval de incredere")
  return(interval)
}
t_conf_interval_fisier("history.txt",0.05)
#IV.5
#Am pus urmatorul sir de numere in "esantion.txt"
#12 11 12 10 11 12 13 12 11 11 13 14 10
t_conf_interval_fisier("esantion.txt",0.1)
t_conf_interval_fisier("esantion.txt",0.05)
t_conf_interval_fisier("esantion.txt",0.01)


#Testarea ipotezelor statistice


alfa = 0.01
n = 100
succese = 63
p_prim = succese/n
p0 = 0.6
z_score = (p_prim - p0)/sqrt(p0*(1 - p0)/n)
critical_z = qnorm(1 - alfa, 0, 1)
z_score
critical_z
#0.61237<1.6448,
#deci ipoteza nula nu se poate respinge.

test_proportion= function(n, p0, succese, alfa, ipoteza){
  #as. la standa = 'left', 
  #as. la dreapta = 'right' 
  #simetrica = 'sim'
  p_prim = succese/n;
  z_score = (p_prim - p0)/(sqrt(p0*(1 - p0)/n));
  if(ipoteza=='left'){
    critical_z = qnorm(alfa,0,1);
    if(z_score < critical_z){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza alternativa \n");
    }
  }
  if(ipoteza=='right'){
    critical_z = qnorm(1 - alfa,0,1);
    if(z_score > critical_z){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza alternativa \n");
    }
  }
  if(ipoteza=='sim'){
    critical_z = qnorm(1 - alfa/2);
    if(abs(z_score) > abs(critical_z)){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza alternativa \n");
    }
  }
  cat("Scorul:", z_score," Valoarea critica: ", critical_z, "\n");
}

#p'=0.63>p0=0.6=>as la dreapta
test_proportion(100,0.6,63,0.01,'right')

#V.2
#p=20/150=0.1333
#p0=0.1
#p>p0=> as la dreapta
test_proportion(150,0.1,20,0.05,'right')

# test_proportion= function(n, p0, succese, alfa, ipoteza)


test_proportion(150,0.1,20,0.05,'right')

#V.3
test_proportion(42,0.25,17,0.01,'left')

