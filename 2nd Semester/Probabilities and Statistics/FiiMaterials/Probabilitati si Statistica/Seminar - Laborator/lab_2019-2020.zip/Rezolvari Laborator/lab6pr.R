#Testarea ipotezelor statistice
#I. Inferenta asupra mediei-Testul Z pentru media unei populatii
#cu dispersia cunoscuta

test_z= function(n, population_mean, sample_mean,dispersion, alfa, ipoteza){
  #as. la standa = 'left', 
  #as. la dreapta = 'right' 
  #simetrica = 'sim'
  sigma=sqrt(dispersion)
  z_score = (sample_mean - population_mean)/(sigma/sqrt(n));
  if(ipoteza=='left'){
    critical_z = qnorm(alfa,0,1);
    if(z_score < critical_z){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu sunt suficiente dovezi pentru a respinge ipoteza nula \n");
    }
  }
  if(ipoteza=='right'){
    critical_z = qnorm(1 - alfa,0,1);
    if(z_score > critical_z){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu sunt suficiente dovezi pentru a respinge ipoteza nula \n");
    }
  }
  if(ipoteza=='sim'){
    critical_z = qnorm(1 - alfa/2);
    if(abs(z_score) > abs(critical_z)){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu sunt suficiente dovezi pentru a respinge ipoteza nula \n");
    }
  }
  cat("Scorul:", z_score," Valoarea critica: ", critical_z, "\n");
}

#Exemplul propus: 

#Media esantionului=816>810=> As la dreapta
population_mean=810
n=200
#media esantionului
sample_mean=816
sigma=50
test_z(200,810,816,50^2,0.05,'right')

#I.2
#dispersia=144
#n=49
#sample_mean=88
#media<90

#Media esantionului 88 < 90=> Testez ipoteza de asimetrie la stanga

test_z(49,90,88,144,0.01,'left')
test_z(49,90,88,144,0.05,'left')
#I.3
population_mean=75
dispersion=17
n=36
sample_mean=85
#Studentii sunt atipici- incerc o ipoteza simetrica
test_z(36,75,85,17,0.01,'sim')
#Se accepta ipoteza alternativa=>studentii sunt atipici

#I.4
population_mean=21
alfa=0.01
n=100
sample_mean=20.5
sigma=2.5
#mu_0=21 
#mu=20.5 < 21
test_z(100,21,20.5,(2.5)^2,0.01,'left')


#I.5
population_mean=1000
n=100
sample_mean=970
sigma=85
# media esantionului<1000=> as la stanga
test_z(100,1000,970,85^2,0.05,'left')
#DA
test_z(100,1000,970,85^2,0.01,'left')

#I.6
pop_mean=22
sigma=3
n=16
sample_mean=20
#ipoteza simetrica
test_z(16,22,20,9,0.01,'sim')
#Da
test_z(16,22,20,9,0.05,'sim')

#II - Testul t pentru media unei populatii cu dispersia necunoscuta
test_t= function(n, population_mean, sample_mean,sigma, alfa, ipoteza){
  #as. la standa = 'left', 
  #as. la dreapta = 'right' 
  #simetrica = 'sim'
  se=sigma/sqrt(n)
  t_score = (sample_mean - population_mean)/se;
  if(ipoteza=='left'){
    critical_t = qt(alfa,n-1);
    if(t_score < critical_t){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  if(ipoteza=='right'){
    critical_t = qt(1 - alfa,n-1);
    if(t_score > critical_t){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  if(ipoteza=='sim'){
    critical_t = qt(1 - alfa/2,n-1);
    if(abs(t_score) > abs(critical_t)){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  cat("Scorul:", t_score," Valoarea critica: ", critical_t, "\n");
}

#Exemplu 
x=scan()
sample_mean=mean(x)
sigma=sd(x)
n=length(x)
#media nivelului de glucoza este mai mare de 40
test_t(n,40,sample_mean,sigma,0.05,'right')


##Testul T cu citire din fisier

test_t_fisier= function(filename, population_mean, alfa, ipoteza){
  #as. la standa = 'left', 
  #as. la dreapta = 'right' 
  #simetrica = 'sim'
  x=scan(filename)
  n=length(x)
  sample_mean=mean(x)
  sigma=sd(x)
  se=sigma/sqrt(n)
  t_score = (sample_mean - population_mean)/se;
  if(ipoteza=='left'){
    critical_t = qt(alfa,n-1);
    if(t_score < critical_t){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  if(ipoteza=='right'){
    critical_t = qt(1 - alfa,n-1);
    if(t_score > critical_t){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  if(ipoteza=='sim'){
    critical_t = qt(1 - alfa/2,n-1);
    if(abs(t_score) > abs(critical_t)){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  cat("Scorul:", t_score," Valoarea critica: ", critical_t, "\n");
}
test_t_fisier("Fisier",40,0.05,'right')

#II.2
test_t_fisier("Fisier2",34,0.01,'sim')
#II.3
test_t(100,11.4,11.9,0.25,0.01,'sim')
test_t(100,11.4,11.9,0.25,0.05,'sim')
#II.4
test_t_fisier("History.txt",80,0.01,'sim')

#II.5
test_t(65,49,52,sqrt(89.5),0.01,'sim')

#II.6
test_t(40,30,29,sqrt(5),0.05,'left')


#Testul Z pentru diferenta mediilor unor populatii
#cu dispersii cunoscute

test_z_diferenta_medii= function(n1,n2,m0,sample_mean1,sample_mean2,sigma1,sigma2, alfa, ipoteza){
  #as. la standa = 'left', 
  #as. la dreapta = 'right' 
  #simetrica = 'sim'
combined_sigma=sqrt(sigma1^2/n1+sigma2^2/n2)
    z_score = ((sample_mean1 - sample_mean2)-m0)/sqrt((sigma1^2)/n1+(sigma2^2)/n2);
  if(ipoteza=='left'){
    critical_z = qnorm(alfa,0,1);
    if(z_score < critical_z){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  if(ipoteza=='right'){
    critical_z = qnorm(1 - alfa,0,1);
    if(z_score > critical_z){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  if(ipoteza=='sim'){
    critical_z = qnorm(1 - alfa/2);
    if(abs(z_score) > abs(critical_z)){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
  }
  cat("Scorul:", z_score," Valoarea critica: ", critical_z, "\n");
}

#Exercitiul rezolvat
sigma1=4
sigma2=3
n1=100
n2=100
sample_mean1=48
sample_mean2=47
#Testez media1-media2!=0
test_z_diferenta_medii(100,100,0,48,47,4,3,0.05,'sim')

#III.2
n1=80
sample_mean1=160
sigma1=3.24
n2=70
sample_mean2=155
sigma2=2.25
test_z_diferenta_medii(80,70,0,160,155,3.24,2.25,0.01,'sim')

#III.3
#verific media1-media2<0
test_z_diferenta_medii(100,100,0,22.8,23.3,1.3,1.9,0.01,'left')


#IV. Inferenta asupra dispersiilor a doua populatii - Testul F

test_F= function(n1,n2,s1,s2, alfa, ipoteza){
  #as. la dreapta = 'right' 
  #simetrica = 'sim'
  F_score = s1^2/s2^2
  if(ipoteza=='right'){
    critical_F = qf(1 - alfa,n1-1,n2-1);
    if(F_score > critical_F){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
    cat("Scorul:", F_score," Valoari critica: ", critical_F, "\n");
  }
  if(ipoteza=='sim'){
    critical_Fs = qf(alfa/2,n1-1,n2-1);
    critical_Fd = qf(1-alfa/2,n1-1,n2-1);
    if((F_score<critical_Fs )||(F_score>critical_Fd)){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
    cat("Scorul:", F_score," Valori critice: ", critical_Fs, critical_Fd,  "\n");
  }
}
#Exemplul rezolvat
test_F(120,135,5.05,5.44,0.01,'sim')


#Test F cu citire din fisier cu doua coloane


test_F_fisier= function(filename, alfa, ipoteza){
  #as. la dreapta = 'right' 
  #simetrica = 'sim'
  x1=read.table(filename, header = T)[['A']]
  x2=read.table(filename, header = T)[['B']]
  n1=length(x1)
  n2=length(x2)
  s1=sd(x1)
  s2=sd(x2)
  F_score = s1^2/s2^2
  if(ipoteza=='right'){
    critical_F = qf(1 - alfa,n1-1,n2-1);
    if(F_score > critical_F){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
    cat("Scorul:", F_score," Valoari critica: ", critical_F, "\n");
  }
  if(ipoteza=='sim'){
    critical_Fs = qf(alfa/2,n1-1,n2-1);
    critical_Fd = qf(1-alfa/2,n1-1,n2-1);
    if((F_score<critical_Fs )||(F_score>critical_Fd)){
      cat("Se respinge ipoteza nula si se accepta ipoteza alternativa \n");
    }
    else{
      cat("Nu se poate respinge ipoteza nula, nu sunt suficiente dovezi \n");
    }
    cat("Scorul:", F_score," Valori critice: ", critical_Fs, critical_Fd,  "\n");
  }
}

#IV.2
test_F_fisier("program",0.01,'sim')
#Nu am suficiente dovezi

test_F_fisier("program",0.05,'sim')



#Iv.3
x1=c(12.512,12.869,19.098,15.350,13.297,15.589)
x2=c(11.074,9.686,12.164,8.351,12.182,11.489)
test_F(length(x1),length(x2),sd(x1),sd(x2),0.05,'sim')
