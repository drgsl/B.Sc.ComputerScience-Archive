#Stem and leaf 
#11 14 21 32 17 24 21 35 52 44 21 28 36 49 41 19 20 34 37 29
x=scan()
stem(x)
#0.6 0.2 1.6 2.0 1.1 0.5 1.5 2.3 3.4 1.9
y=scan()
stem(y)

#Histograme
#Exemplul rezolvat
z=scan("sample1.txt")
min=min(z)
print(min)
max=max(z)
max
#Putem alege sa impartim valorile pe intervalele 
#[40; 50), [50; 60) etc [90; 100)
intervale=seq(40,100,10)
hist(z,breaks = intervale,right=F,freq =T,col="blue")
#sau
a=6
hist(z,breaks = a,right=F,freq =T,include.lowest=T, col="blue")


#Barchart Pareto
frecv = c(9, 8, 12, 3, 17, 41, 29, 35, 32, 40, 19, 8)
barplot(frecv, space = 0,col="red")

#EXERCITII PROPUSE

#I1.
x=scan("sample1.txt")
stem(x)

#I2.
#Observ ca trebuie sa impart in subintervalele:
#(0; 4], (4; 6], (6; 8], (8; 10], (10; 12], (12; 14] si (14; 300].
interval=c(0,4,6,8,10,12,14,100,300)
#interval=seq(0,300,2)
tablou=read.csv("unemploy2012.csv",header = T, sep=';')
rate=tablou[['rate']]
hist(rate, breaks = interval,right = T)


#I.3
tabel=read.csv("life_expect.csv",header = T, sep=',')
country=tabel[['country']]
male=tabel[['male']]
female=tabel[['female']]
female
a=7
hist(male, breaks = a,right = T,col="red")
hist(male, breaks = a,right = T, col="blue")

#II. ANALIZA TENDINTEI CENTRALE
#media
#II.1 
x=scan("sample1.txt")
mean(x)
median(x)

#II.2
tabel=read.csv("life_expect.csv",header = T, sep=',')
country=tabel[['country']]
male=tabel[['male']]
female=tabel[['female']]

mean(male)
median(male)
mean(female)
median(female)
#II.3.*
#Modul este valoarea care are cea mai mare frecventa Ä±n esantion.
x=c(3, 6, 4, 3, 6, 7, 8, 5, 3, 6, 7, 7 ,7 )
modul=function(x){
  z=scan(x)
  result = vector()
  i_result = 1;
  fmax=1
  fcurent=1
  i=2
  a=sort(z)
  while(i<=length(a)){
    if(a[i]==a[i-1]){
      fcurent=fcurent+1
    }else{
      if(fcurent>fmax){
        fmax=fcurent
        fcurent=1
        # print("Actualizare")
        # print(a[i-1])
        # print(fmax)
        # print("----")
        result = vector()
        i_result = 1;
        result[i_result] = a[i-1]
      } 
      else if (fcurent == fmax) {
        fcurent = 1
        i_result = i_result + 1
        result[i_result] = a[i-1]
     } else {
        fcurent = 1
      }
    }
    i = i+1
  }
  print(fmax)
  return(result)
}
modul("sample2.txt")

#III Imprastierea si valorile aberante

x=c(2, 6, 4, 3, 6, 7, 8, 5, 6,4)
#domeniul datelor
range=max(x)-min(x)
print(range)
#Deviatia standard
sd(x)
# sqrt(var(x))
#dispersia
var(x)
#quartilele si intervalul interquartilic (IQR):
quantile(x)
y=vector()
Q1=as.vector(quantile(x))[1+1]
Q1
Q3=as.vector(quantile(x))[3+1]
Q3
IQR=Q3-Q1
IQR
summary(x)

#Valorile aberante (outliers)

x= c(1, 91, 38, 72, 13, 27, 11, 85, 5, 22, 20, 19, 8, 17, 11, 15, 13, 23, 14, 17)

#III.1

valori_aberante_met1=function(x){
m=mean(x)
print(m)
s=sd(x)
print(s)
y=vector()
k=1
for (i in 1:length(x)) {
  print(x[i])
  if((x[i] <= (m-2*s)) | (x[i] >= (m+2*s))){
    y[k] = x[i]
    k = k+1
  }
}
print(y)
print(m-2*s)
print(m+2*s)

print("Valorile aberante: ")
return(y)
}

valori_aberante_met1(x)



#III.2
valori_aberante_met2=function(x){
Q1 = as.vector(quantile(x))[1+1]
print("Q1")
print(Q1)
Q3 = as.vector(quantile(x))[3+1]
print("Q3")
print(Q3)
IQR = Q3-Q1
  y = vector()
  z = vector()
  l = 0
  k = 1
  for (i in 1:length(x)) {
    if((x[i] <= (Q1-1.5*IQR))|(x[i]>=(Q3+1.5*IQR))){
      y[k] = x[i]
      k = k+1
    }
  }
  print("----")
  print(Q1-1.5*IQR)
  print(Q3+1.5*IQR)
  
  print("Valorile aberante: ")
  return(y)
}
valori_aberante_met2(x)


#III.3

x=scan("sample2.txt")
summary(x)
valori_aberante_met1(x)
valori_aberante_met2(x)
