A1geom = function(p,k,l)
{
  x=k:l;
  print(x);
  y=dgeom(x,p);
  barplot(y);
  print(max(y));
}
A1geom(0.5,5,14)


