#A2
#sbpct a


A2.a = function(file)
{
  var = scan(file)
  v=vector()
  v[1]=median(var)
  v[2]=mean(var)
  v[3]=sd(var)
  v[4]=as.vector(quantile(var))[2]
  v[5]=as.vector(quantile(var))[5]
  return (v)
}

A2.a("oyoyoy.txt")

# b

A2.b = function(file)
{
  var = scan(file)
  v2=vector()
  mean=mean(var)
  sd = sd(var)
  
  tot=1
  for(i in 1:length(var))
  {
    if(var[i]>=mean-2 & var[i]<=mean+2)
    {
      v2[tot] = var[i]
      tot=tot+1
    }
  }
  return(v2)
}
A2.b("oyoyoy.txt")

#sbpct c

A2.c = function(file)
{
  var = A2.b(file)
  pause = seq(40, max(var) + 5, 5)
  
  
  hist(var, breaks=pause, main="Distributia Frecventelor", right=F, freq=T)
}

A2.c("oyoyoy.txt")