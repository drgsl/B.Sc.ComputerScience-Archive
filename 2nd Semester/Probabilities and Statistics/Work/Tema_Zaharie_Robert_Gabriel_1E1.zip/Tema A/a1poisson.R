A1.poisson = function(lambda,k,l)
{
  x=k:l;
  print(x);
  y=dpois(x,lambda);
  plot(y,type='l',main='poisson graph');
  print(max(y));
}
A1.poisson(8,5,14)


