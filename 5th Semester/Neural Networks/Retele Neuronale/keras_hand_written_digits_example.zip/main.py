import numpy as np
from keras.utils.np_utils import to_categorical
from tensorflow.keras.datasets import mnist
import matplotlib.pyplot as plt
from tensorflow.keras import models, layers


def display_image(image):
    pixels = np.array(image, dtype='int32')
    pixels = pixels.reshape((28, 28))
    plt.imshow(pixels, cmap='gray', vmin=0, vmax=255)
    plt.show()


def show_history(history):
    accuracy = history['accuracy']
    val_accuracy = history['val_accuracy']
    loss = history['loss']
    val_loss = history['val_loss']

    epochs = range(1, len(accuracy) + 1)
    plt.plot(epochs, accuracy, 'bo', label='Training Accuracy')
    plt.plot(epochs, val_accuracy, 'b', label='Validation Accuracy')
    plt.title('Validation and Training Accuracy')
    plt.legend()
    plt.figure()

    plt.plot(epochs, loss, 'bo', label='Training Loss')
    plt.plot(epochs, val_loss, 'b', label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.legend()
    plt.show()


def main():
    (train_images, train_labels), (test_images, test_labels) = mnist.load_data()

    # display_image(train_images[0])

    # Datasets
    train_images = train_images.reshape(60000, 28 * 28)
    train_images = train_images.astype('float32') / 255

    test_images = test_images.reshape(10000, 28 * 28)
    test_images = test_images.astype('float32') / 255

    train_labels = to_categorical(train_labels)
    test_labels = to_categorical(test_labels)

    # Neural Network
    nn = models.Sequential()

    nn.add(layers.Dense(100, activation='sigmoid', input_shape=(28 * 28, ))) # only for the first layer we need to specify input_shape
    nn.add(layers.Dense(10, activation='softmax'))

    nn.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])

    # Stats
    history = nn.fit(train_images, train_labels, validation_data=(test_images, test_labels), epochs=20, batch_size=128)
    show_history(history.history)

    # Output Of NN
    prediction = nn(test_images)
    print(prediction[0])


if __name__ == '__main__':
    main()

