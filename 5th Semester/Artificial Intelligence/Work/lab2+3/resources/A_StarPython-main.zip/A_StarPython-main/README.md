# A_StarPython
Solved Water Jug problem with A star algorithm 
