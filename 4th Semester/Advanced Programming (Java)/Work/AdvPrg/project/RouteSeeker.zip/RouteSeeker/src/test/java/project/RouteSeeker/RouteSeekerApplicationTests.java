package project.RouteSeeker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RouteSeekerApplicationTests {

	@Test
	void contextLoads() {
	}

}
