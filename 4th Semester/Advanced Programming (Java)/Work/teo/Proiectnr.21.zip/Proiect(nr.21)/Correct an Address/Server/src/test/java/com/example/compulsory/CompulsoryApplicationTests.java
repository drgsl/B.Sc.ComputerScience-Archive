package com.example.compulsory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompulsoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
