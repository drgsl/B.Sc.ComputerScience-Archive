package smartCity.model;

import lombok.Data;

@Data
public class Locatie {
    private double latitudine;
    private double longitudine;
}
