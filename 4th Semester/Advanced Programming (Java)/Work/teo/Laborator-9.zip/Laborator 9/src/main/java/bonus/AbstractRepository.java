package bonus;

public interface AbstractRepository {

}
