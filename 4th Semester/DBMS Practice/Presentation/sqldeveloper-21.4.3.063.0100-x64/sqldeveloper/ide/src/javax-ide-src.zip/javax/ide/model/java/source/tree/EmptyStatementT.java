/*
 * @(#)EmptyStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An empty statement. JLS3 14.6. <p/>
 *
 * @author Andy Yu
 * */
public interface EmptyStatementT
  extends SimpleStatementT
{
}
