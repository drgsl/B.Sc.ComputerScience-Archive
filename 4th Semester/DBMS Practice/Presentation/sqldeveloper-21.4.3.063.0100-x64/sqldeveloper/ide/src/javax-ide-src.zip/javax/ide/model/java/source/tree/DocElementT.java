/*
 * @(#)DocElementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * @deprecated
 */
abstract class DocElementT
{
}
