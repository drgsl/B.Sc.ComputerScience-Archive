/*
 * @(#)HasAnnotationsD.java
 */

package javax.ide.model.java.declaration;

import java.util.Collection;

/**
 * Common supertype for Declaration elements that may have annotations.
 *
 * @author Andy Yu
 */
public interface HasAnnotationsD
  extends Declaration
{
  /**
   * Gets the annotations on this element.
   *
   * @return The collection of annotation declarations for the annotations
   * on this element. <p/>
   *
   * Collection of AnnotationDs.
   */
  public Collection getAnnotations();
}
