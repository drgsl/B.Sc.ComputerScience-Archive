/*
 * @(#)ParameterD.java
 */

package javax.ide.model.java.declaration;

/**
 * Represents a local variable.
 *
 * @author Andy Yu
 */
public interface LocalVariableD
  extends Declaration, HasNameD, HasTypeD, HasAnnotationsD
{
}
