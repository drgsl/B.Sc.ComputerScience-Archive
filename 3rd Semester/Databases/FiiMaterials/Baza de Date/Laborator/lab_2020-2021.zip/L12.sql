SELECT e2.nume FROM elev e JOIN prieten p ON e.id = p.id1 JOIN elev e2 ON e2.id = p.id2 WHERE e.nume='Gabriel'

