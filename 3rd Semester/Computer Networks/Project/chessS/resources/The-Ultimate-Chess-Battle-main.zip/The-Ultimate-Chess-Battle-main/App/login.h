#pragma once

#include "../config.c"

void loginFunctionality(GameScreen * currentScreen);
void loginVisual();