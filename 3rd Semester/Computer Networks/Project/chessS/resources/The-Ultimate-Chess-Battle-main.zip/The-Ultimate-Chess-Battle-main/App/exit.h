#pragma once

#include "../config.c"

void exitFunctionality(GameScreen * currentScreen, int * framesCounter);
void exitVisual();