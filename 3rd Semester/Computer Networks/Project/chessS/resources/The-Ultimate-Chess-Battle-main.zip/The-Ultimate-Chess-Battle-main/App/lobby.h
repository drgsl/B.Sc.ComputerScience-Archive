#pragma once

#include "../config.c"

void lobbyFunctionality(GameScreen * currentScreen, int * framesCounter);
void lobbyVisual();