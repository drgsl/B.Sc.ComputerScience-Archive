#pragma once

#include "../config.c"

void logoFunctionality(GameScreen * currentScreen, int * framesCounter);
void logoVisual();