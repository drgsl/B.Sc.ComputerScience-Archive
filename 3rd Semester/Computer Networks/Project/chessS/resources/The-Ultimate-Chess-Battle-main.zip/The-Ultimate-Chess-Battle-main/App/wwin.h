#pragma once

#include "../config.c"

void wwinFunctionality(GameScreen * currentScreen, int * framesCounter);
void wwinVisual();