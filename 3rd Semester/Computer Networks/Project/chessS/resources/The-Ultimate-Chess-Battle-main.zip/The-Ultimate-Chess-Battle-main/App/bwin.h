#pragma once

#include "../config.c"

void bwinFunctionality(GameScreen * currentScreen, int * framesCounter);
void bwinVisual();