#pragma once
#include "../config.c"
// #include 

void startupScreen();
void initialiseTable(squares * square);