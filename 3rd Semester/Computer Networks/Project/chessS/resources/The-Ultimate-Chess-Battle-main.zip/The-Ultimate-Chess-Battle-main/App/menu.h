#pragma once

#include "../config.c"

void menuFunctionality(GameScreen * currentScreen, int * framesCounter);
void menuVisual();