#pragma once

#include "../config.c"

void optionsFunctionality(GameScreen * currentScreen, int * framesCounter);
void optionsVisual();